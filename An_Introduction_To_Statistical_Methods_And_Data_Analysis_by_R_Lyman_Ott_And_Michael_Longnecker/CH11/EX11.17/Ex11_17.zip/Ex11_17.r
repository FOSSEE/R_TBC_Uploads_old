my_data=read.table(file.choose(),header = TRUE)
attach(my_data)
str(my_data)
cor.test(y,x,conf.level = 0.95) 
