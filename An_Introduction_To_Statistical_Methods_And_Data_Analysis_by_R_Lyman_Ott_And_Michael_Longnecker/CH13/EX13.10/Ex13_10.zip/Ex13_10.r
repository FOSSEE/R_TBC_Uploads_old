my_data <- read.table(file.choose(), header=T)
attach(my_data)
str(my_data)
 model1=lm(REDUCTION~GENDER+AGE+GENDER:AGE+BEFORE+GENDER:BEFORE,data = my_data)
 anova(model1)
 summary(model1)
# regression equation : y= 6.41 + 7.51x1 - .115x2 + .000531x3 + .091x1x2 - .00441x1x3
 # for males equation (x1=0):y=6.41-.115x2+.000531x3
 # for females equation (x1=1): y= 13.92 - .024x2 - .00388x3
  