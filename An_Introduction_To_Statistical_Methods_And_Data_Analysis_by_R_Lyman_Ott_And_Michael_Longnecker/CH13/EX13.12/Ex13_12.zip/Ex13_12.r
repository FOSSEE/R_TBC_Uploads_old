my_data <- read.table(file.choose(), header=T)
attach(my_data)
str(my_data)
d2=DOSE^2
model1=lm(BOUND~DOSE+d2,data = my_data)
summary(model1)
anova(model1) 
