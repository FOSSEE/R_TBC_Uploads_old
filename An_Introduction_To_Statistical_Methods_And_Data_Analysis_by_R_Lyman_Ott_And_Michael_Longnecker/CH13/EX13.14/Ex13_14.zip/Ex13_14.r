my_data <- read.table(file.choose(), header=T)
attach(my_data)
str(my_data)
d2=Diameter^2
model1=lm(Age~Diameter+d2,data = my_data)
summary(model1)
anova(model1) 
# regression equation : y=-593+14.4*Diameter-0.03*d2