library(fclust)


d <-  read.table(file.choose(),head=TRUE,",")



cluster=FKM(d[,1:(ncol(d))],k=2,m=1.5,stand=1)

print(cluster)