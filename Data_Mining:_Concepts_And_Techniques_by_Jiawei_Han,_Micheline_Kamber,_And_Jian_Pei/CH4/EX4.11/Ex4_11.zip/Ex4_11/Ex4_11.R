####install package sqldf

install.packages("sqldf")

## Query for characterization

library(sqldf)


Tab1 <- read.table(file.choose(),head=TRUE,",")

Tab2 <- read.table(file.choose(),head=TRUE,",")

Tab3 <- read.table(file.choose(),head=TRUE,",")




Total <-sqldf("select A_key, D from Tab1 union select A_key, D from Tab2 union select A_key, D from Tab3")






Combine<-sqldf("select Total.*, Tab1.S, Tab2.S, Tab3.S FROM ((Total LEFT JOIN Tab1 ON Total.A_key = Tab1.A_key) LEFT JOIN Tab2 ON Total.A_key = Tab2.A_key) LEFT JOIN Tab3 ON Total.A_key = Tab3.A_key")




char <- sqldf("select * from Combine where A_key='2'")


View(char)









