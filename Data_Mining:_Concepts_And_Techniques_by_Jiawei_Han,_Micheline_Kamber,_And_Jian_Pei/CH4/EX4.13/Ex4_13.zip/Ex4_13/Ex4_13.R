## Query for characterization

library(sqldf)

Dataset <- read.table(file.choose(),head=TRUE,",")


barplot(as.matrix(Dataset[,3:4]))





Locations <- c("Asian", "Europe", "North America", "Asian", "Europe", "North America")

Items <- c("TV", "TV", "TV", "Computer", "Computer", "Computer")


sales <- c(15,12,28,120,150,200)


Count <- c(300,250,450,1000,1200,1800)


pie(sales, labels = Locations, main="Pie Chart for Countries")









