library(sqldf)
library(gsubfn)
library(proto)
library(RSQLite)



d <- read.table(file.choose(),head=TRUE,",")



m1 <-print(sqldf("SELECT avg(income) FROM d where age='25'"))
m2 <-print(sqldf("SELECT avg(income) FROM d where age='23'"))
m3 <-print(sqldf("SELECT avg(income) FROM d where age='31'"))

View((m1+m2+m3)/3)
