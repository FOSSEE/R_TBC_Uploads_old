
library(sqldf)
library(gsubfn)
library(proto)
library(RSQLite)



d <- read.table(file.choose(),head=TRUE,",")



View(sqldf("SELECT * FROM d where occupation='teacher' and gender='male'"))


