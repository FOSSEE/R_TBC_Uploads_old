library(sqldf)
library(gsubfn)
library(proto)
library(RSQLite)



d <- read.table(file.choose(),head=TRUE,",")


### retrieve Top 2 programers where gender= male and occupation= programer in descending order


View(sqldf("SELECT * FROM d where gender='male' and occupation='programmer' order by occupation desc limit 2"))


