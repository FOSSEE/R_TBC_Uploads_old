
####install.packages("arules")

library(arules)



transactions <- read.table(file.choose(),head=TRUE,",")


Ass_rules <- apriori(transactions,parameter = list(supp = 0.001, target="frequent"))



inspect(Ass_rules)
