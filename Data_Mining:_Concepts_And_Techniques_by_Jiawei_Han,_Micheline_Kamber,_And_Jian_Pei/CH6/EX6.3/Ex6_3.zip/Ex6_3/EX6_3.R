library(arules)

transactions <- read.table(file.choose(),head=TRUE,",")


Ass_rules <- apriori(transactions,parameter = list(supp = 0.001, conf = 0.001))

inspect(Ass_rules)
