library(arules)

##### rules based on lift 

transactions <- read.table(file.choose(),head=TRUE,",")




Ass_rules <- apriori(transactions, parameter = list(support= 0.001, conf=0.001))

lift <- subset(Ass_rules, subset = lift >0.5)

inspect(lift)