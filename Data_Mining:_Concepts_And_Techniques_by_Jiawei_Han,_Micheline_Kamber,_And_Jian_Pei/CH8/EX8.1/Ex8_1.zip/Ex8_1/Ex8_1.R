###Install package 
install.packages("FSelector")
#### Call Felector Package 
library(FSelector)

### Create object d for input file
d <- read.table(file.choose(),head=TRUE,",")



Info_gain <- information.gain(Class_Buys_Computer~ ., data=d) 


View(Info_gain)


	


