
#### Call Felector Package 
library(FSelector)

### Create object d for input file
d <- read.table(file.choose(),head=TRUE,",")



gain_ratio <- gain.ratio(Class_Buys_Computer~ ., data=d) 


print(gain_ratio)
	


