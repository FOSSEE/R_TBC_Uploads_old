
#### Call rpart Package (Which uses Gini index to construct decision tree)	

library(rpart)

### Create object d for input file
d <- read.table(file.choose(),head=TRUE,",")



dt_CART <- rpart(Class_Buys_Computer~ ., method="class", data=d)



summary(dt_CART)
	


