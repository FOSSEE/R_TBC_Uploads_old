## Install package install.packages("e1071")



#### Call e1071 Package (Which has implementation of Naive bayers classifier)	

library(e1071)

### Create object d for input file
data <- read.table(file.choose(),head=TRUE,",")



### Split data into 30% test data and 70% traing data

ind <- sample(1:nrow(data), size=0.3*nrow(data))

# Split data
testData = data[ind,]
dim(testData) 
trainData = data[-ind,]
dim(trainData) 


dt <- naiveBayes(Class_Buys_Computer~ ., data=trainData, trials=1) 
pdw <- predict(dt,  newdata=testData, type = "class" )

print("Predicted classes are:")

print(pdw)
	


