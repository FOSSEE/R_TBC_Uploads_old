
### Create object d for input file

data <-  read.table(file.choose(),head=TRUE,",")


total_Instances <- length(data)

Total_Youth <- which(data$Age == "Youth" & data$Student == "yes" & data$Class_Buys_Computer== "yes")

l1 <- length(Total_Youth);

print("Coverage")

Coverage <- l1/total_Instances

print(Coverage)

print("Accuracy")

Accuracy <- (Total_Youth)/(l1)

print(Accuracy)










