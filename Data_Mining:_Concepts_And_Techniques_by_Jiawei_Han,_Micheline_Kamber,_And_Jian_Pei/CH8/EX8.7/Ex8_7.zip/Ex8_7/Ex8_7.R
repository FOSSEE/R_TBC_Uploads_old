
	

library(C50)

### Create object d for input file
d  <- read.table(file.choose(),head=TRUE,",")



Rules<- C5.0(Class_Buys_Computer~., data =d, rules = TRUE)


View(summary(Rules))





