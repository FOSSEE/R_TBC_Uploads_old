c<-c(63,29,20.8,19.1,13.4,8.5)
r<-c(7,3.9,2.1,2.8,1.4,1.5)
plot(c,r,main = "cars and revenue", xlab="No. of cars", ylab="revenue", pch=19)
