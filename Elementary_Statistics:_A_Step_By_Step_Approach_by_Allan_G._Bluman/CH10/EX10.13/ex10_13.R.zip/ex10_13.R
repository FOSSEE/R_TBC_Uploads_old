c<-c(1,2,3,4,4,6)
r<-c(62,78,70,90,93,103)
y=r*c
y1=r*r
a=55.57
b=8.13
s=sqrt((sum(y1)-(a*sum(r))-(b*sum(y)))/(length(c)-2))
l<-paste("standard error is",round(s,2))
l