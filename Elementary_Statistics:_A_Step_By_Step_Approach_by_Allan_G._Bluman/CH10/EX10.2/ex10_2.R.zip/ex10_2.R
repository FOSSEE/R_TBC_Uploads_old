c<-c(6,2,15,9,12,5,8)
r<-c(82,86,43,74,58,90,78)
plot.default(c,r,main = "Study of absetees vs grades", xlab="No. of absentees", ylab="final grades in percentage", pch=19)
