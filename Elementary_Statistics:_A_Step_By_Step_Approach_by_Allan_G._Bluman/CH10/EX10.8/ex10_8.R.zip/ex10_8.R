c<-c(3,0,2,5,8,5,10,2,1)
r<-c(48,8,32,64,10,32,56,72,48)
cor.test(c,r,method = "pearson", conf.level = 0.90)