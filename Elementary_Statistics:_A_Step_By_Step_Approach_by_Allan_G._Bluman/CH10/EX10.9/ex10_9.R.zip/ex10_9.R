c<-c(63,29,20.8,19.1,13.4,8.5)
r<-c(7,3.9,2.1,2.8,1.4,1.5)
df=data.frame(c,r)
scatter.smooth(c,r,xlab="cars",ylab="revenue")
LinearMod<-lm(formula = r ~ c, data = df)
LinearMod