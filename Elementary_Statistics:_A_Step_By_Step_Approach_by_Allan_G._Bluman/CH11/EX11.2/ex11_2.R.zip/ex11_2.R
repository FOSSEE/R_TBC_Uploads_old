oo<-c(0.38,0.32,0.23,0.07)
n=length(oo)
c=qchisq(0.9,n-1)
o<-300*oo
o
e<-c(122,85,76,17)
x<-sum(((o-e)^2)/e)
x
if(x>c)
  l<-paste("Null hypothesis rejected") else
    l<-paste("Null hypothesis accepted")
l