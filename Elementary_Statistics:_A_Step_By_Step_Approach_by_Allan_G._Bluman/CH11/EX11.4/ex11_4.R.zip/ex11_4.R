l<-c(89.5,104.5,119.5,134.5,149.5,164.5)
h<-c(104.5,119.5,134.5,149.5,164.5,179.5)
f<-c(24,62,72,26,12,4)
n<-length(f)
xm<-(l+h)/2
fxm<-f*xm
fxm2<-f*(xm*xm)
xbar<-sum(fxm)/sum(f)
s<-sqrt(((sum(f)*sum(fxm2))-(sum(fxm)^2))/(sum(f)*(sum(f)-1)))
z=(h[1]-xbar)/s
z2=(h[2]-xbar)/s
z3=(h[3]-xbar)/s
z4=(h[4]-xbar)/s
z5=(h[5]-xbar)/s
az=round(pnorm(z),4)
az2=round(pnorm(z2),4)-az
az3=round(pnorm(z3),4)-round(pnorm(z2),4)
az4=round(pnorm(z4),4)-round(pnorm(z3),4)
az5=round(pnorm(z5),4)-round(pnorm(z4),4)
az6=1-round(pnorm(z5),4)
oo<-c(az,az2,az3,az4,az5,az6)
e<-round(oo*200,1)
e
x<-sum(((f-e)^2)/e)
x
c=qchisq(0.95,n-2)
if(x>c)
  l<-paste("Null hypothesis rejected") else
    l<-paste("Null hypothesis accepted")
l
#there is an error in the answer in the textbook