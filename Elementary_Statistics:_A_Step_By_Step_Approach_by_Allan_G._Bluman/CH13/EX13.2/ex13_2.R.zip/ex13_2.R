c=qt(0.05,50)
x=21
n=50
z=((x+0.5)-(50/2))/(sqrt(n)/2)
if(z>c)
  l<-paste("Null hypothesis accepted") else
    l<-paste("Null hypothesis rejected")
l