b<-c(7,2,3,6,5,8,12)
a<-c(5,3,4,3,1,6,4)
wilcox.test(a,b,paired = TRUE)