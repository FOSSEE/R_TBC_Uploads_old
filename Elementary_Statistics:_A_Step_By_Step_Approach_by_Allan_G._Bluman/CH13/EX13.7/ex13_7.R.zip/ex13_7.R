s1<-c(4,10,18,20,12,2,5,9)
s2<-c(4,6,20,14,16,8,11,7)
cor.test(s1,s2,method = "spearman")