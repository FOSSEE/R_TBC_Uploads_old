d<-c(20, 26, 40, 36, 23, 42, 35, 24, 30)
round(mean(d), digit=1)