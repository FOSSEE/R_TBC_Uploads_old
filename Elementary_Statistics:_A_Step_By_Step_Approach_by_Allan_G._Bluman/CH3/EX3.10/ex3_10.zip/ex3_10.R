getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
coal<-c(110, 731, 1031, 84, 20, 118, 1162, 1977, 103, 752)
result<-getmode(coal)
if(result==coal[1]) {print("no mode")} else {print(result)}