getmode <- function(v,v1) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
lnr<-c(104, 104, 104, 104, 104, 107, 109, 109, 109, 110, 109, 111, 112, 111, 109)
result<-getmode(lnr)
result
