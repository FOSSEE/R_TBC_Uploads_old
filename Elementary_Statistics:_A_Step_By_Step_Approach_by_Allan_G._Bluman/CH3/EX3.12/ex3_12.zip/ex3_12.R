breaks1<-seq(5.5, 35.5, by=5)
breaks2<-seq(10.5, 40.5, by=5)
fr<-c(1,2,3,5,4,3,2)
max(fr)
d=fr
i=1
while(d[i]!=max(fr)){i=i+1}
lbls<-paste(breaks1[i],"-",breaks2[i]," is the modal class")
lbls