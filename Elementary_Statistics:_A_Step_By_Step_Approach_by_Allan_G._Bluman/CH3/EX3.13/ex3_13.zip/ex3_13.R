sm<-c(1425, 878, 632, 471, 95)
nms<-c("Business","Liberal Arts","Computer Science","Education","General Studies")
d=sm
max(sm)
i=1
while(d[i]!= max(sm)){i=i+1}
lbls<-paste(nms[i],"major is the mode")
lbls