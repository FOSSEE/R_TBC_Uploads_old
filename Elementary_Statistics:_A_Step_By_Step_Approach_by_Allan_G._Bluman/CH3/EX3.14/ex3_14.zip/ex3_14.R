occ<-c("Owner", "Manager", "Salesperson", "Technician1", "Technician2")
sal<-c(50000, 20000, 12000, 9000, 9000)
mean(sal)#mean
median(sal)#median
getmode <- function(v,v1) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
mod<-getmode(sal)
mod#mode