mr<-c(2, 3, 6, 8, 4, 1)
H=max(mr)
L=min(mr)
midrange<-(H+L)/2
lbs<-paste(midrange," is the midrange of the given dataset")
lbs