nfl<-c(18.0, 14.0, 34.5, 10, 11.3, 10, 12.4, 10)
H=max(nfl)
L=min(nfl)
midrange<-(H+L)/2
lbs<-paste(midrange," is the midrange of the given dataset")
lbs