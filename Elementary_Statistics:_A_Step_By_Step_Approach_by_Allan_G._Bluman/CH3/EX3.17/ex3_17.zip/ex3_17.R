cred<-c(3, 3, 4, 2)
gr<-c(4, 2, 3, 1)
wt<-weighted.mean(gr,cred)
lbs<-paste(round(wt,1)," is the weighted mean of the given dataset")
lbs