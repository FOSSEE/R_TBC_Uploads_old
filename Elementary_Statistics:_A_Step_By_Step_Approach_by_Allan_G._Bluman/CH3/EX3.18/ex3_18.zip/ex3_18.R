a<-c(10, 60, 50, 30, 40, 20)
b<-c(35, 45, 30, 35, 40, 25)
lbs1<-paste("mean of brand A is", round(mean(a), digits=1), "months")
lbs2<-paste("mean of brand B is", round(mean(b), digits=1), "months")
lbs1
lbs2