a<-c(10, 60, 50, 30, 40, 20)
b<-c(35, 45, 30, 35, 40, 25)
H1=max(a)
H2=max(b)
L1=min(a)
L2=min(b)
lbs1<-paste("Range of brand A is", H1-L1, "months")
lbs2<-paste("Range of brand B is", H2-L2, "months")
lbs1
lbs2