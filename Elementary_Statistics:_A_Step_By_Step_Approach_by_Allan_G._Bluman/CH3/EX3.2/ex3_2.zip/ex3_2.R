boat<-c(3782, 6367, 9002, 4208, 6843, 11008)
round(mean(boat), digit=1)