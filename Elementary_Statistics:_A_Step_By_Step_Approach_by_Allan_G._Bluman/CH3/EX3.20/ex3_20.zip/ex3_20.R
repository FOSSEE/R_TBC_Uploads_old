sal<-c(100000, 40000, 30000, 25000, 15000, 18000)
H=max(sal)
L=min(sal)
lbs<-paste("The range of salary is", H-L, "$")
lbs