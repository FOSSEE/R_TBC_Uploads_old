a<-c(10, 60, 50, 30, 40, 20)
lbs1<-paste(round(var(a), digits=1),"is the variance")
lbs2<-paste(round(sd(a), digits=1),"is the standard deviation")
lbs1
lbs2
#variance and standard deviation around sample mean is calculated, not population mean