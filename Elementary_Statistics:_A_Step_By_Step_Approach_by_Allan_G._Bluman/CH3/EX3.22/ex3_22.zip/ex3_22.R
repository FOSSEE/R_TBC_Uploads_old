b<-c(35, 45, 30, 35, 40, 25)
lbs1<-paste(round(var(b), digits=2),"is the variance")
lbs2<-paste(round(sd(b), digits=2),"is the standard deviation")
lbs1
lbs2
#variance and standard deviation around sample mean is calculated, not population mean