eas<-c(11.2, 11.9, 12.0, 12.8, 13.4, 14.3)
lbs1<-paste("Sample Variance is",var(eas))
lbs2<-paste("standard deviation is",round(sd(eas),digits=2))
lbs1
lbs2