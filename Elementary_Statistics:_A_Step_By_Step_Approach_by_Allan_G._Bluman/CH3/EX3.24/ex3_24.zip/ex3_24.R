breaks1<-seq(5.5,35.5,by=5)
breaks2<-seq(10.5,40.5,by=5)
mp<-(breaks1+breaks2)/2
f<-c(1,2,3,5,4,3,2)
d<-f*mp
e<-f*mp*mp
n<-((sum(f)*sum(e))-(sum(d)*sum(d)))
t<-sum(f)
v<-n/(t*(t-1))
lbs<-paste(round(v, digits=1),"is the variance")
lbss<-paste(round(sqrt(v), digits=1),"is the standard deviation")
lbs
lbss
