mean1<-87
sd1<-5
mean2<-5225
sd2<-773
lbs1<-paste("coefficient of variation is",round(sd1/mean1*100, digits=1),"%sales")
lbs2<-paste("coefficient of variation is",round(sd2/mean2*100, digits=1),"%commission")
lbs1
lbs2
if(round(sd1/mean1*100, digits=1)>round(sd2/mean2*100, digits=1)){print("Sales is more variable than commission")}
if(round(sd1/mean1*100, digits=1)<round(sd2/mean2*100, digits=1)){print("Commission is more variable than sales")}
