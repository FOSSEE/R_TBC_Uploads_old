va1<-23
mean1<-132
va2<-62
mean2<-182
lbs1<-paste("coefficient of variation is",round(sqrt(va1)/mean1*100, digits=1),"% pages")
lbs2<-paste("coefficient of variation is",round(sqrt(va2)/mean2*100, digits=1),"% advertisements")
lbs1
lbs2
if(round(sqrt(va1)/mean1*100, digits=1)>round(sqrt(va2)/mean2*100, digits=1)){print("pages is more variable than advertisements")}
if(round(sqrt(va1)/mean1*100, digits=1)<round(sqrt(va2)/mean2*100, digits=1)){print("Advertisements is more variable than pages")}
