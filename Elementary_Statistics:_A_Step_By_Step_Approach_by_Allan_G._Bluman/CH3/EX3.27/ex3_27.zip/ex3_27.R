pct=0.75
k=sqrt(1/(1-pct))
meanh=50000
sdh=10000
r1=meanh+(k*sdh)
r2=meanh-(k*sdh)
lbs<-paste("The range is between",r2,"to",r1)
lbs