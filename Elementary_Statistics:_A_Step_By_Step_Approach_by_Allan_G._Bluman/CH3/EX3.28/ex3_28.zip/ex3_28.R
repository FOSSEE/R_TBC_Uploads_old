r2=0.30
r1=0.20
meant<-0.25
sdt<-0.02
k=(r1-meant)/sdt
pct=1-1/(k*k)
lbs<-paste("percentage obtained is", pct*100, "%")
lbs