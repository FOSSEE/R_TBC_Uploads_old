#calculus
value1<-65
meanv1<-50
sdv1<-10
z1=(value1-meanv1)/sdv1
#history
value2<-30
meanv2<-25
sdv2<-5
z2=(value2-meanv2)/sdv2
if(z1>z2){print("She has done her Calculus test better")}
if(z1==z2){print("Both tests have been done equally well")}
if(z1<z2){print("She has done her history test better")}