breaks1= seq(5.5, 35.5, by=5)
breaks2= seq(10.5, 40.5, by=5)
tbl<-c(1, 2, 3, 5, 4, 3, 2)
mp<-(breaks2+breaks1)/2
meantotal<-(sum(((breaks2+breaks1)/2)*tbl)/sum(tbl))
meantotal