#testA
meana<-40
sda<-5
valuea<-38
za<-(valuea-meana)/sda
#testB
meanb<-100
sdb<-10
valueb<-94
zb<-(valueb-meanb)/sdb
if(za>zb){print("She has done her A test better")}
if(za==zb){print("Both tests have been done equally well")}
if(z1<z2){print("She has done her B test better")}