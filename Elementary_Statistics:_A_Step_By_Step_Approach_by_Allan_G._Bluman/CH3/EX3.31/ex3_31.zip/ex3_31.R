breaks1=seq(89.5,179.5, by=15)
freq<-c(0,24,62,72,26,12,4)
pct<-cumsum(freq)/2
plot(breaks1,pct,type="o", main="percentile plot")
