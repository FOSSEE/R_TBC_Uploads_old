test<-c(18, 15, 12, 6, 8, 2, 3, 5, 20, 10)
i<-1
j=0
while(i<=length(test)){if(test[i]<12) {j=j+1};i=i+1; }
ptl=(j+0.5)/length(test)
lbs<-paste(ptl*100,"%is the percentile of the mark 12")
lbs
