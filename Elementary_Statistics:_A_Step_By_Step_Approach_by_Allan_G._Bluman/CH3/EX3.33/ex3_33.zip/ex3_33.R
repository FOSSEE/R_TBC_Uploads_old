test<-c(18, 15, 12, 6, 8, 2, 3, 5, 20, 10)
f<-(mean(6>test))+0.05
lbs<-paste(f*100,"%is the percentile of the mark 6")
lbs
#percentile=reverse quantile