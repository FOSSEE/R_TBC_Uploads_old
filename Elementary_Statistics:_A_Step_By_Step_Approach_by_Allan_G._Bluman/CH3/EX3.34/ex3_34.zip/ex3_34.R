ptl<-0.25
test<-c(18, 15, 12, 6, 8, 2, 3, 5, 20, 10)
v<-round(quantile(test,ptl,TRUE,1))
lbs<-paste("the mark corresponding to 25 percentile is",v)
lbs