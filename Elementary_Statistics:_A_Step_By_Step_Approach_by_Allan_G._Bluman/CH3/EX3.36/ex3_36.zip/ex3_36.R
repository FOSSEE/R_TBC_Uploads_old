ds<-c(15, 13, 6, 5, 12, 50, 22, 18)
lbs1<-paste(quantile(ds,0.25,1,TRUE,2),"=Q1")
lbs1
lbs2<-paste(quantile(ds,0.5,1,TRUE,2),"=Q2")
lbs2
lbs3<-paste(quantile(ds,0.75,1,TRUE,2),"=Q3")
lbs3