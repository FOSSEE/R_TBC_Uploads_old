ds<-c(15, 13, 6, 5, 12, 50, 22, 18)
iqr<-IQR(ds,type = 2)
q1<-quantile(ds,0.25,type = 2)
q3<-quantile(ds,0.75, type = 2)
r1=q1-(1.5*iqr)
r2=q3+(1.5*iqr)
if(max(ds)>r2){lb<-paste(max(ds),"is a outliner");
lb}else{print("no outliner")}
