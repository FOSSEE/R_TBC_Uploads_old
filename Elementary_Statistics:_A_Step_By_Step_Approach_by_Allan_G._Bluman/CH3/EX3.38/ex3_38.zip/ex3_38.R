met<-c( 89, 47, 164, 296, 30, 215, 138, 78, 48, 39)
boxplot(met,horizontal = TRUE)