rc<-c(310, 420, 45, 40, 220, 240, 180, 90)
cs<-c(270, 180, 250, 290, 130, 260, 340, 310)
boxplot(rc,cs, horizontal=TRUE, main="Amount of cheese present")
#boxplot(cs, horizontal=FALSE)
