room<-c( 713, 300, 618, 595, 311, 401, 292)
median(room)
