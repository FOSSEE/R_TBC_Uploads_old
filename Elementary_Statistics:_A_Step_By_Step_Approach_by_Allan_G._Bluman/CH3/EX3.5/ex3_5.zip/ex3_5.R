amt<-c(25, 15, 15, 20, 15)
lbl<-paste("$", median(amt))
lbl