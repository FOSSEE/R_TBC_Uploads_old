mgz<-c(1, 7, 3, 2, 3, 4)
median(mgz)