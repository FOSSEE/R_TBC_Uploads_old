nfl<-c(18.0, 14.0, 34.5, 10, 11.3, 10, 12.4, 10)
getmode <- function(v) {
  uniqv <- unique(v)
  uniqv[which.max(tabulate(match(v, uniqv)))]
}
result<-getmode(nfl)
result