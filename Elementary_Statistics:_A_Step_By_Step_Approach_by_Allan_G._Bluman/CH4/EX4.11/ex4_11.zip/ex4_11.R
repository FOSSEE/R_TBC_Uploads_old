pic<-1/5
pnic<-1-pic
lbs<-paste("Probability that he doesn't live in an industrial country is",pnic)
lbs