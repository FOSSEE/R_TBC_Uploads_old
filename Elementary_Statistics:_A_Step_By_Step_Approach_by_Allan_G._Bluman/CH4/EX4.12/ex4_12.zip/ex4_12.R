f<-c(41,6,3)
labe<-c("drive","fly","train or bus")
pr<-f[2]/sum(f)
lbs<-paste("The probability of the person flying is",round(pr,digits=3))
lbs