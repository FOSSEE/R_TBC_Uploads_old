ss<-50
o<-21
a<-22
b<-5
ab<-2
pro<-o/ss
praob<-(a+b)/ss
prn<-(ss-a-o)/ss
prnab<-(ss-ab)/ss
print("the answers are as follows")
pro
praob
prn
prnab