f<-c(20,13,6)
pr<-(f[2]+f[3])/sum(f)
v<-paste("The answer is",round(pr,digits=2))
v