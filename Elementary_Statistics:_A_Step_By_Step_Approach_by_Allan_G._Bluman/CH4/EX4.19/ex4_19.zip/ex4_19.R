ss<-7
we<-2
pr<-we/ss
n<-paste("the answer is",round(pr,digits = 2))
n