ss<-52
a<-4
bc<-26
extra<-2#2 aces counted twice
pr<-(a+bc-extra)/ss
n<-paste("the answer is",round(pr, digits = 2))
n