ssc<-2
ssd<-6
h<-1
c<-1
pr<-(c/ssd)*(h/ssc)
n<-paste("The probability is",round(pr,digits=3))
n