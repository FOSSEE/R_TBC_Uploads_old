ss<-52
a<-4
q<-4
pr<-(a/ss)*(q/ss)
n<-paste("The probabilityb is",round(pr,digits=3))
n