r<-3
b<-2
w<-5
ss<-r+b+w
pra<-(b/ss)*(b/ss)
prb<-(b/ss)*(w/ss)
prc<-(r/ss)*(b/ss)
print("The answers are")
pra
prb
prc