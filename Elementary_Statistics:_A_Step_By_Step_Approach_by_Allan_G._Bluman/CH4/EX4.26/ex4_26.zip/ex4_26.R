pr<-0.46
p<-pr*pr*pr
print("The probability is")
p