ss<-13*4#sample space of an entire deck of cards excluding jokers
ra<-2#number of red aces is 2
p<-ra/ss
lbs<-paste("Probability of getting a red ace is",round(p,digits=2))
lbs