ch<-3#total number of children
po<-2#no. of girls
typ<-2#gender of children
ss<-typ^ch
g2<-3#bgg,gbg,ggb
lbs<-paste("Probability of having two girl children is",round(g2/ss,digits=3))
lbs