ss<-52
nj<-4#number of jacks
c6<-1#no. of 6 clubs
n3<-4#no.of threes
nd<-13#no. of diamonds
n6<-4#no. of 6
a<-nj/ss
b<-c6/ss
c<-(n3+nd)/ss
d<-(n3+n6)/ss
print("the answers are")
a
b
c
d