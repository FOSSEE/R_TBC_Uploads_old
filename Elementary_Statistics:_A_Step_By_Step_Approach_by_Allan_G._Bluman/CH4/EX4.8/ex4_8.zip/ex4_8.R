ss<-c(1,2,3,4,5,6)
v<-9
i=1
j=0
while(i<=length(ss)){if(ss[i]==v)j=j+1;i=i+1}
if(j>0){print(v/length(ss));}
if(j==0){print("Probability is zero as value doesn't exist in sample space")}