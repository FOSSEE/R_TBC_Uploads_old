ss<-c(1,2,3,4,5,6)
i=1
j=0
while(i<=length(ss)){if(ss[i]<=7)j=j+1;i=i+1}
lbs<-paste("probability is",j/length(ss))
lbs