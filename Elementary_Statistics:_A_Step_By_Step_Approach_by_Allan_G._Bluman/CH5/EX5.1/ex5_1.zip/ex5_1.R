ss<-c(1,2,3,4,5,6)
pr<-c(1/length(ss),1/length(ss),1/length(ss),1/length(ss),1/length(ss),1/length(ss))
tbl<-data.frame(ss,pr)
tbl