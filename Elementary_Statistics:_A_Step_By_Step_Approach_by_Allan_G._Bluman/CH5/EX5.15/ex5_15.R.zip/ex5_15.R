ss<-2
nc<-3
d<-choose(3,2)
ans<-d/(ss^nc)
n<-paste("Probability is",ans)
n
