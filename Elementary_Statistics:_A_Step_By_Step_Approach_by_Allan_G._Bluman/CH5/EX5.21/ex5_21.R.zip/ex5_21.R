n=4
p=q=0.5
x<-paste("Mean is",n*p)
x
y<-paste("Variance is",n*p*q)
y
z<-paste("Standard Variance is",sqrt(n*p*q))
z