n=360
p=round(1/6,5)
q=round(5/6,5)
x<-paste("Mean is",round(n*p))
x
y<-paste("Variance is",round(n*p*q))
y
z<-paste("Standard Variance is",round(sqrt(n*p*q),2))
z