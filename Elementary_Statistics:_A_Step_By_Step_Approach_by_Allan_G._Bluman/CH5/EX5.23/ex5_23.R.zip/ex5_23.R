n=8000
p=0.02
q=0.98
x<-paste("Mean is",n*p)
x
y<-paste("Variance is",n*p*q)
y
z<-paste("Standard Variance is",round(sqrt(n*p*q),2))
z