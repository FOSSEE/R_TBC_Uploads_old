a=b=5
n=X=3
P=dhyper(X,a,b,n)
l<-paste("Probability is",round(P,3))
l
