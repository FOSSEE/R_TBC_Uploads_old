a=2
b=8
n=5
X=1
P=(choose(a,X)*choose(b,n-X)/choose(a+b,n))
P=dhyper(X,a,b,n)
l<-paste("Probability is",round(P,3))
l
