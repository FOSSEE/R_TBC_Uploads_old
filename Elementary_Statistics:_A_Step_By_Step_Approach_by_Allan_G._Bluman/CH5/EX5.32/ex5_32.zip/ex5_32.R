a=3 
b=9
n=3
X=0
P=dhyper(X,a,b,n)
l<-paste("Probability of atleast one being defective is",round(1-P,2))
l
