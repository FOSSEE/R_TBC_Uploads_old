g<-paste("area less than z=1.99 is",round(pnorm(1.99)*100,2),"%")
g
x=seq(-4,4,length=200)
 y=dnorm(x)
 plot(x,y,type="l", lwd=2, col="blue")
 x=seq(-4,1.99,length=200)
 y=dnorm(x)
 polygon(c(-4,x,1.99),c(0,y,0),col="gray")