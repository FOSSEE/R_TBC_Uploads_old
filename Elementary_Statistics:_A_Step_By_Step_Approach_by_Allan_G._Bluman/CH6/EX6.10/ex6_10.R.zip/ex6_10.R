m=120
sd=8
z1=0.84
z2=-0.84
x1=round((z1*sd)+m,4)
x2=round((z2*sd)+m,4)
g<-paste("the middle 60% will have blood pressure readings of",x1,"and",x2)
g