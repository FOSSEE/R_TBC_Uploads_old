m=25
n=20
si=3
sm=si/sqrt(n)
x=26.3
z=(x-m)/sm
l<-paste(" the probability of obtaining a sample mean larger than 26.3 hours is",round((1-pnorm(z))*100,2))
l