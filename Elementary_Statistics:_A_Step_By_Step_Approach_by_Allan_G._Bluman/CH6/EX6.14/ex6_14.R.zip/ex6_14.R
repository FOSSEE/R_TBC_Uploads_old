m=96
n=36
si=16
sm=si/sqrt(n)
x1=90
x2=100
z1=(x1-m)/sm
z2=(x2-m)/sm
l<-paste("the probability of obtaining a sample mean between 90 and 100 months is ",round((pnorm(z2)-pnorm(z1))*100,2),"%")
l