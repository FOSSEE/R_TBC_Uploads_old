n=300
p=0.06
q=0.94
m=n*p
sd=sqrt(n*p*q)
x1=25.5
x2=24.5
z1=(x1-m)/sd
z2=(x2-m)/sd
l<-paste(" the probability that exactly 25 people read the newspaper while driving is",round(pnorm(z1)-pnorm(z2),4))
l