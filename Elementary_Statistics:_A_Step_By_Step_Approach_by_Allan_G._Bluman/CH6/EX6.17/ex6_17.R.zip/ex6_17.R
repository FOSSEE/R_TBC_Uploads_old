n=200
p=0.1
q=0.9
m=n*p
sd=round(sqrt(n*p*q),3)
x1=9.5
z1=(x1-m)/sd
l<-paste(" the probability of 10 or more widowed people in a random sample of 200 bowling league members is",round(1-pnorm(z1),4))
l