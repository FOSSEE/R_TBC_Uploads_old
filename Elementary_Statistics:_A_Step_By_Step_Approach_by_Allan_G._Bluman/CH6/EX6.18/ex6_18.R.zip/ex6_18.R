n=100
p=0.32
q=0.68
m=n*p
sd=round(sqrt(n*p*q),3)
x1=26.5
z1=(x1-m)/sd
l<-paste("the probability that the player will get at most 26 hits in 100 times at bat. Solution is",round(pnorm(z1),4))
l
