n=10
p=0.5
q=0.5
m=n*p
sd=round(sqrt(n*p*q),3)
x1=6.5
x2=5.5
z2=(x2-m)/sd
z1=(x1-m)/sd
l<-paste("probability that X=6 is",round(pnorm(z1)-pnorm(z2),4))
l
#the answer obtained here is more closer to the table's value