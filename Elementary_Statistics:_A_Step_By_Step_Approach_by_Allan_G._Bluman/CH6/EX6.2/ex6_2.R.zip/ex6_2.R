g<-paste("area right of z=-1.16 is",round((1-pnorm(-1.16))*100,2),"%")
g
x=seq(-4,4,length=200)
y=dnorm(x)
plot(x,y,type="l", lwd=2, col="red")
x=seq(-1.16,4,length=200)
y=dnorm(x)
polygon(c(-1.16,x,4),c(0,y,0),col="gray")