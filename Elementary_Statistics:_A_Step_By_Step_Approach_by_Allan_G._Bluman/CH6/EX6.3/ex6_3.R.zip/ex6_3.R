g<-paste("area right of z=-1.16 is",round((pnorm(1.68)-pnorm(-1.37))*100,2),"%")
g
x=seq(-4,4,length=200)
y=dnorm(x)
plot(x,y,type="l", lwd=2, col="blue")
x=seq(-1.37,1.68,length=100)
y=dnorm(x)
polygon(c(-1.37,x,1.68),c(0,y,0),col="gray")