g<-paste("Probability is",round((pnorm(2.32)-pnorm(0)),4))
g
x=seq(-4,4,length=200)
y=dnorm(x)
plot(x,y,type="l", lwd=2, col="blue")
x=seq(0,2.32,length=100)
y=dnorm(x)
polygon(c(0,x,2.32),c(0,y,0),col="gray")