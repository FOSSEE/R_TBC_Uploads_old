g<-paste("Probability is",round((pnorm(1.65)),4))
g
x=seq(-4,4,length=200)
y=dnorm(x)
plot(x,y,type="l", lwd=2, col="green")
x=seq(1.65,-4,length=100)
y=dnorm(x)
polygon(c(1.65,x,-4),c(0,y,0),col="gray")