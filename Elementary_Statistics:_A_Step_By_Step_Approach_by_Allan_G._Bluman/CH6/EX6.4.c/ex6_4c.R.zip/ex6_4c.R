g<-paste("Probability is",round((1-pnorm(1.91)),4))
g
x=seq(-4,4,length=200)
y=dnorm(x)
plot(x,y,type="l", lwd=2, col="blue")
x=seq(1.91,4,length=100)
y=dnorm(x)
polygon(c(1.91,x,4),c(0,y,0),col="red")