X=160.00
m=146.21
sd=29.44
z=round((X-m)/sd,2)
g<-paste(round(pnorm(z)*100,2),"% of the women spend less than $160.00 at christmas time")
g