X=15
m=25
sd=4.5
ss=80
z=round((X-m)/sd,2)
y=round(pnorm(z),4)
g<-paste(y*ss,"call will be responded to in under 15 minutes.")
g