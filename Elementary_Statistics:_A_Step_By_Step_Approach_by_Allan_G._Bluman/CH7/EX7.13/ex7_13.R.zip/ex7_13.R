qchisq(0.1/2,24)
qchisq(0.95,24)