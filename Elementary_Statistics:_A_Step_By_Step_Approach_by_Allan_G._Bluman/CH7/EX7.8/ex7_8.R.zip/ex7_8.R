x=54
n=150
p=round((x/n),2)
q=1-p
l<-paste("p=",p,"q=",q)
l