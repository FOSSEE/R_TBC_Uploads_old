x=qt(0.1/2,18)
l<-paste("+/-",round(abs(x),3),"is the critical value")
l