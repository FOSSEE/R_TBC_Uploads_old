x=qt(0.05,28)
l<-paste(round(abs(x),3),"is the critical value")
l