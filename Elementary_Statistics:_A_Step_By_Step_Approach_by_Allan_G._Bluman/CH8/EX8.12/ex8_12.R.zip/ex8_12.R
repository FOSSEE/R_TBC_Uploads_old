m=17.7
mu=16.3
s=1.8
n=10
c=round(abs(qt(0.05,9)),2)
z=round((m-mu)/(s/sqrt(n)),2)
f=round(pnorm(-abs(z)),4)
if(z>c) 
{l<-paste("hypothesis rejected")} else 
{l<-paste("Hypothesis accepted")}
l

