n=11
t=2.056
p=pt(-abs(t),df=n-1)
l<-paste("P value =",round(p,3))
l