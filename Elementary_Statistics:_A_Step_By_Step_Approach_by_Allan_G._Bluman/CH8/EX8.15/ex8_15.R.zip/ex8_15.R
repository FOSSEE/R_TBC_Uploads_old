n=6
t=2.983
p=2*pt(-abs(t),df=n-1)
l<-paste("P value =",round(p,3))
l