m=40.6
mu=36.7
s=6
n=15
t=round((m-mu)/(s/sqrt(n)),2)
p=2*pt(-abs(t),df=n-1)
l<-paste("P value =",round(p,3))
l
a=0.05
if(a>p)
  j<-paste("Hypothesis rejected") else
    j<-paste("Hypothesis accepted")
j