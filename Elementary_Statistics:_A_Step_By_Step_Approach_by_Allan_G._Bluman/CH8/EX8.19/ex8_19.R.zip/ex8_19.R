mu=0.77
n=80
x=55
p=x/n
p
q=1-mu
c=-round(qt(0.99,n-1),2)
c
z=(p-mu)/sqrt(mu*q/n)
if((z>c))
  l<-paste("Hypothesis rejected") else
    l<-paste("Hypothesis accepted")
l