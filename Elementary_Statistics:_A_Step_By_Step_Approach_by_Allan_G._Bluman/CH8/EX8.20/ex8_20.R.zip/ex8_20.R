mu=0.25
x=63
n=200
p=x/n
q=1-mu
z=(p-mu)/sqrt(mu*q/n)
pp=pt(-abs(z),df=n-1)
c=0.05
if(pp<c)
  l<-paste("hypothesis accepted") else
    l<-paste("hypothesis rejected")
l