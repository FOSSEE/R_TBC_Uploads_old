l<-paste(round(qchisq(0.05,10),3),"is the critical value")
l