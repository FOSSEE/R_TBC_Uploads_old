s2=225
a=0.95
n=23
c=qchisq(1-a,n-1)
s=198
x=(n-1)*s/s2
if(x>c)
  l<-paste("There is not enough evidence to support the claim that the variation in test scores of the instructor’s students is less than the variation in scores of the population. ")
l