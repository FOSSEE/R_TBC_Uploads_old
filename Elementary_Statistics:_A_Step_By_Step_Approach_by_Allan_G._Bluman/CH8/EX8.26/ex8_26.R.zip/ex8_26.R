s2=0.644
a=0.05
n=20
c1=qchisq(1-a/2,n-1)
c2=qchisq(a/2,n-1)
s=1
x=(n-1)*s*s/s2
if(x>c2 && x<c1)
  l<-paste("hypothesis accepted")
l