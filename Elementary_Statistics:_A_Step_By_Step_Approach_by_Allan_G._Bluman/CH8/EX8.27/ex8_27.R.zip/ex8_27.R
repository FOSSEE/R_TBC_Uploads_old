y=pchisq(19.274,7,lower.tail = FALSE)
l<-paste("p value is",round(y,3))
l