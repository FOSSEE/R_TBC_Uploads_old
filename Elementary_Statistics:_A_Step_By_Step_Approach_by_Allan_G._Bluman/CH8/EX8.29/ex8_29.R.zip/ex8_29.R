s2=16.8
s=12.5
n=24
x=(n-1)*s*s/(s2^2)
p=2*pchisq(x,23)
a=0.05
if(a<p)
  l<-paste("Hypothesis rejected")
l