m=5950
mu=5700
s=659
n=36
c=0.05
z=round((m-mu)/(s/sqrt(n)),2)
f=round(pnorm(-abs(z)),4)
if(f<c) 
  {l<-paste("hypothesis rejected")} else 
  {l<-paste("Hypothesis accepted")}
l