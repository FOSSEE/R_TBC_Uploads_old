m=8.2
mu=8
s=0.6
n=32
c=0.05
z=round((m-mu)/(s/sqrt(n)),2)
f=2*round(pnorm(-abs(z)),4)
if(f<c) 
{l<-paste("hypothesis rejected")} else 
{l<-paste("Hypothesis accepted")}
l