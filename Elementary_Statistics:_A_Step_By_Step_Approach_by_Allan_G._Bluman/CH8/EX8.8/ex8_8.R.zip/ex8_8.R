x=qt(0.05,16)
l<-paste(round(abs(x),3),"is the critical value")
l