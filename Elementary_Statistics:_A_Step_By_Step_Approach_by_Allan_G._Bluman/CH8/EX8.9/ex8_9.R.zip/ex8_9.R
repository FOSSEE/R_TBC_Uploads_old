x=qt(0.01,22)
l<-paste(round(x,3),"is the critical value")
l