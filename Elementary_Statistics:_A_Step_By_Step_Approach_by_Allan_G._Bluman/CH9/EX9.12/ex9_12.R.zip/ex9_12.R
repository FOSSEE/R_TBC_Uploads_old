y=round(qf(0.95,15,21),2)
l<-paste("Critical value is",y)
l