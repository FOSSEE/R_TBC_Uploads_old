v1=21
v2=12
a=0.05
y=round(qf(1-a/2,v1-1,v2-1),2)
l<-paste("Critical value is",y)
l