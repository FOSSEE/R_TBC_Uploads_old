n1=26
n2=18
s1=36
s2=10
f=s1/s2
f
c=round(qf(1-0.05/2,24,n2-1),2)
c
if(f>c)
  l<-paste("Null hypothesis rejected. There is enough evidence to support the claim that the variance of the heart rates of smokers and nonsmokers is different.") else
    l<-paste("Null hypothesis accepted")
l