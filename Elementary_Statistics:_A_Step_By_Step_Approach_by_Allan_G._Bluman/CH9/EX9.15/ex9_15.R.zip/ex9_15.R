n1=16
n2=18
s1=32
s2=28
f=(s1*s1)/(s2*s2)
round(f,2)
c=round(qf(1-0.01,n1-1,n2-1),2)
c
if(f<c)
  l<-paste("Null hypothesis accepted.There is not enough evidence to support the claim that the standard deviation of the waiting times of the first hospital is greater than the standard deviation of the waiting times of the second hospital.") else
    l<-paste("Null hypothesis rejected")
l