w1<-c(36.8,72.4,60.5,73.5,61.2,40.1)
w2<-c(60.7,51.2,42.7,38.6)
s1=sd(w1)^2
s2=sd(w2)^2
f=s1/s2
round(f,2)
c=round(qf(0.90,5,3),2)
c
if(f>c)
  l<-paste("Null hypothesis rejected.") else
    l<-paste("Null hypothesis accepted.There is not enough evidence to support the claim that the variance in the number of passengers for American airports is greater than the variance in the number of passengers for foreign airports.")
l