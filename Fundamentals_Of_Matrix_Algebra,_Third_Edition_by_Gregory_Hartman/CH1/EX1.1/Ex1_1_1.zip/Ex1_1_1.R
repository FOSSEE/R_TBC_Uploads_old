### Page number 2
###This is a conceptual question so we can solve it by only hand


print("Since we know there are 30 marbles in the jar so")
print("r + b + g = 30")
print("there are twice as many red marbles as green ones")
print("r = 2 * g")
print("number of blue marbles is the same as the sum of the red and green marbles")
print("b = r + g")
print("b = 2g + g = 3g")
print("r + b + g = 30
       2g + 3g + g = 30
       6g = 30
       g = 5")

print("Hence r = 10 , b = 15 , g = 5")