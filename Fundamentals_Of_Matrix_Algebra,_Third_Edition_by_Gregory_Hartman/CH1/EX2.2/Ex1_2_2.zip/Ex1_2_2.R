### Page number 9
print("Original system of equations")
showEqn(A)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4]
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4]
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 =",d1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 =",d2))
  print(paste(a3,"x1 +",b3,"x2 +",c3,"x3 =",d3))
}
A <- matrix(c(1,2,-1,1,2,1,1,1,-2,0,0,2),ncol = 4)
print("Corresponding matrix")
print(A)
R1 <- A[1,]
R2 <- A[2,]
R3 <- A[3,]
print("−2R1 + R2 → R2 and R1 + R3 → R3 )")
R2 <- R2 + (-2)* R1
R3 <- R1 + R3
A <- rbind(R1,R2,R3)
print(A)
print("R2 ↔ R3")
R2 <- R2 + R3
R3 <- R2 - R3
R2 <- R2 - R3
A <- rbind(R1,R2,R3)
print(A)
print(" 1/2 R2 → R2 and −1R3 → R3")
R2 <- (1/2) * R2
R3 <- (-1) * R3
A <- rbind(R1,R2,R3)
print(A)
print("−R3 + R1 → R1 and 1/2 R3 + R2 → R2")
R1 <- R1 - R3
R2 <- R2 + (1/2) * R3
A <- rbind(R1,R2,R3)
print(A)
print("−R2 + R1 → R1")
R1 <- R1 - R2
A <- rbind(R1,R2,R3)
print(A)
showEqn(A)
print("By This way x1 = -1 , x2 = 1 , x3 = 0 ")




