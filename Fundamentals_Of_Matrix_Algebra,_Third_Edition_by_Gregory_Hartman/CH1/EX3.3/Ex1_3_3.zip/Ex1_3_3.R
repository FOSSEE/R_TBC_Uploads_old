### Page number 14
#1. The first nonzero entry in each row is a 1 (called a leading 1.
#2. Each leading 1 comes in a column to the right of the leading 1s in rows above it.
#3. All rows of all 0s come at the bo om of the matrix.
#4. If a column contains a leading 1, then all other entries in that column are 0.

a <- matrix(c(1,0,0,1),ncol = 2)
b <- matrix(c(1,0,0,1,1,2),ncol = 3)
c <- matrix(c(0,0,0,0),ncol = 2)
d <- matrix(c(1,0,1,0,0,1),ncol = 3)
e <- matrix(c(1,0,0,0,0,0,0,0,1,1,0,3),ncol = 4)
f <- matrix(c(1,0,0,2,0,0,0,3,0,0,0,4),ncol = 4)
g <- matrix(c(0,0,0,1,0,0,2,0,0,3,0,0,0,1,0,4,5,0),ncol = 6)
h <- matrix(c(1,0,0,1,1,0,0,0,1),ncol = 3)
l <- list(a,b,c,d,e,f,g,h)
for(i in l)
{
  print(i)
}
print("The matrices in a, b, c, d and g are all in reduced row echelon form")
print("The matrix e , f , h are not in reduced row echelon form")

