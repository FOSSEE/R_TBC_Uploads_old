### Page number 15
A <- matrix(c(-3,2,0,-3,2,-2,9,-4,-4,12,-2,-8),ncol=4)
showEqn(A)
print("converting the linear system into an augmented matrix")
print(A)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4]
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4]
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 =",d1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 =",d2))
  print(paste(a3,"x1 +",b3,"x2 +",c3,"x3 =",d3))
}
R1 <- A[1,]
R2 <- A[2,]
R3 <- A[3,]
print("−1/3 R1 → R1 and −2R1 + R2 → R2")
R1 <- -(1/3)*R1
R2 <- R2 -2*R1
A <- rbind(R1,R2,R3)
print(A)
print("R2 ↔ R3")
R2 <- R2 + R3
R3 <- R2 - R3
R2 <- R2 - R3
A <- rbind(R1,R2,R3)
print(A)
print("−1/2 R2 → R2")
R2 <- (-1/2) * R2
A <- (rbind(R1,R2,R3))
print(A)
print("1/2 R3 → R3")
R3 <- (1/2)*R3
A <- (rbind(R1,R2,R3))
print(A)
print("3R3 + R1 → R1 and −2R3 + R2 → R2")
R1 <- R1 + 3 * R3
R2 <- R2 - 2 * R3
A <- (rbind(R1,R2,R3))
print(A)
print("−R2 + R1 → R1")
R1 <- R1 - R2
A <- (rbind(R1,R2,R3))
print(A)
print("hence x1 = 7, x2 = −2 and x3 = 3")




