### Page number 18
A <- matrix(c(-2,2,3,-4,4,6,-2,1,1,-10,9,13,0,-2,-4),ncol=5)
R1 <- A[1,]
R2 <- A[2,]
R3 <- A[3,]
print("−1/2 R 1 → R 1")
R1 <- (-1/2)*R1
A <- rbind(R1,R2,R3)
print(A)
print("−2R1 + R2 → R2 and −3R1 + R3 → R3")
R2 <- R2 - 2 * R1 
R3 <- R3 - 3 * R1
A <- rbind(R1,R2,R3)
print(A)
print("−R2 → R2")
R2 <- -R2
A <- (rbind(R1,R2,R3))
print(A)
print("2R2 + R3 → R3")
R3 <- R3 + 2*R2
A <- (rbind(R1,R2,R3))
print(A)
print("−R2 + R1 → R1")
R1 <- R1 - R2
A <- (rbind(R1,R2,R3))
print(A)
print("This final matrix is in reduced row echelon form")



