### Page number 19
A <- matrix(c(1,2,3,2,1,3,1,1,2,3,1,1),ncol=4)
R1 <- A[1,]
R2 <- A[2,]
R3 <- A[3,]
print("−2R1 + R2 → R2")
R2 <- R2 - 2* R1
A <- rbind(R1,R2,R3)
print(A)
print("−3R1 + R3 → R3")
R3 <- R3 - 3 * R1
A <- rbind(R1,R2,R3)
print(A)
print("−1/3 R2 → R2")
R2 <- (-1/3) * R2
A <- rbind(R1,R2,R3)
print(A)
print("3R2 + R3 → R3")
R3 <- R3 + 3 * R2
A <- (rbind(R1,R2,R3))
print(A)
print("−1/3 R3 → R3")
R3 <- (-1/3) * R3
A <- (rbind(R1,R2,R3))
print(A)
print("−3R3 + R1 → R1")
R1 <- R1 - 3 * R3
A <- (rbind(R1,R2,R3))
print(A)
print("−5/3 R3 + R2 → R2")
R2 <- as.double(R2 - (5/3) * R3,length(1))
A <- (rbind(R1,R2,R3))
#to round figure we use as.integer
A[2,4] <- as.integer(A[2,4])
print(A)
print("−2R2 + R1 → R1")
R1 <- R1 - 2 * R2
A <- (rbind(R1,R2,R3))
#to round figure we use as.integer
A[1,4] <- as.integer(A[1,4])
A[2,4] <- as.integer(A[2,4])
print(A)
print("This final matrix is in reduced row echelon form")



