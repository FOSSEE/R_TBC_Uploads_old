### Page number 20
A <- matrix(c(2,1,2,1,-1,2,-1,2,-1,4,12,9),ncol=4)
R1 <- A[1,]
R2 <- A[2,]
R3 <- A[3,]
print("1/2 R1 → R1")
R1 <- (1/2) * R1
A <- rbind(R1,R2,R3)
print(A)
print("−R1 + R2 → R2 and −2R1 + R3 → R3")
R2 <- R2 - R1
R3 <- R3 - 2*R1
A <- rbind(R1,R2,R3)
print(A)
print("−2/3 R2 → R2")
R2 <- (-2/3) * R2
A <- rbind(R1,R2,R3)
print(A)
print("−R2 + R3 → R3")
R3 <- R3 - R2
A <- (rbind(R1,R2,R3))
print(A)
print("3/5 R3 → R3")
R3 <- (3/5) * R3
A <- (rbind(R1,R2,R3))
print(A)
print("5/3 R3 + R2 → R2")
R2 <- R2 + (5/3) * R3
A <- (rbind(R1,R2,R3))
print(A)
print("1/2 R3 + R1 → R1 and −1/2 R2 + R1 → R1")
R1 <- R1 + (1/2)*R3
R1 <- R1 -(1/2)* R2
A <- (rbind(R1,R2,R3))
#for casting integer we use as.integer()
A[1,3] <- as.integer(A[1,3])
A[2,3] <- as.integer(A[2,3])
print(A)
print("This final matrix is in reduced row echelon form")



