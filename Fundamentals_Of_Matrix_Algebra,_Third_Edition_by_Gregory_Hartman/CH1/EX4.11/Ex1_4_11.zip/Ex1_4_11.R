### Page number 29
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,2,1,2,0,4),ncol = 3)
showE <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3]
  a2=M[2,1];b2=M[2,2];c2=M[2,3]
  print(paste(a1,"x +",b1,"y =",c1))
  print(paste(a2,"x +",b2,"y =",c2))
}
showE(A)
print("Creating the corresponding augmented matrix")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showE(A)
print("By The Second Equation 0 x + 0 y = 1 Here 0 = 1 that can't be possible")
print("so therefore the system is inconsistent")

