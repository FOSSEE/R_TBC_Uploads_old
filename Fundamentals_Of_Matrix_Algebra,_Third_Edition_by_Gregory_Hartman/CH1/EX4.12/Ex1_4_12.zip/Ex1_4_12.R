### Page number 30
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,0,0,-1,0,0,0,1,0,2,-3,0,4,7,0),ncol = 5)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];e1=M[1,5]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];e2=M[2,5]
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4];e3=M[3,5]
  
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 +",d1,"x4 =",e1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 +",d2,"x4 =",e2))
  print(paste(a3,"x1 +",b3,"x2 +",c3,"x3 +",d3,"x4 =",e3))
}
print(A)
showEqn(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
print("By The Equation 1 x1 + -1 x2 + 0 x3 + 2 x4 = 4 it is clear that x1 - x2 + 2x4 = 4")
print("And by The Equation 0 x1 + 0 x2 + 1 x3 + -3 x4 = 7 it is clear that x3 - 3x4 = 7")
print("Here x1 = 4 + x2 − 2x4 It is clear that x2 is free")
print("and x3 = 7 + 3x4 it is clear that x4 is free")
print("one perticular solution is x1 = 4 , x2 = 0 , x3 = 7, x4 = 0")
print("Second perticular solution is x1 = 15 , x2 = 1 , x3 = -8 , x4 = -5")

