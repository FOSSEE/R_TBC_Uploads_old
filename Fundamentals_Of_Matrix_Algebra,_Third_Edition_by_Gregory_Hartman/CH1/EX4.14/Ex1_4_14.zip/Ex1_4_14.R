### Page number 32
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,1,1,-1,1,1,5,3),ncol = 4)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];
  
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 =",d1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 =",d2))
}
showEqn(A)
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
print("By The first Equation 1 x1 + 0 x2 + 1 x3 = 4 it is clear that x1 + x3 = 4")
print("And by Second Equation 0 x1 + 1 x2 + 0 x3 = 1  it is clear that x2 = 1")
print("Here x1 = 4 - x3 so x3 is free")
print("one perticular solution is x1 = 4 , x2 = 1 , x3 = 0")
print("Second perticular solution is x1 = 3 , x2 = 1 , x3 = 1")

