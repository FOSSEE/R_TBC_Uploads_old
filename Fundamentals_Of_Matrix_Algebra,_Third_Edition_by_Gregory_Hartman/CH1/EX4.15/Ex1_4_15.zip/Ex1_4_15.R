### Page number 33
###Correction required in book in place of k - 9 we have to put k - 6

A <- matrix(list(1,3,2,'k',3,9),ncol = 3)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];
  a2=M[2,1];b2=M[2,2];c2=M[2,3];
  
  print(paste(a1,"x1 +",b1,"x2 =",c1))
  print(paste(a2,"x1 +",b2,"x2 =",c2))
}
showEqn(A)
print(A)
print("putting the matrix into reduced row echelon form by operation −3R1 + R2 → R2")
#Due to non-numeric argument we can't use formal method
A[2,1] <- 0
A[2,2] <- "k - 6"
A[2,3] <- 0
print(A)
showEqn(A)
print("if k = 6, then x2 is a free variable and we have infinite solutions")
print("If k ! = 9, there is exactly one solution")

