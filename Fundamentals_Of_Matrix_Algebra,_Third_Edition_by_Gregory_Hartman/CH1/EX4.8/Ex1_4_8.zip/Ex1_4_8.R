### Page number 25
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,2,1,2,1,2),ncol = 3)
showE <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3]
  a2=M[2,1];b2=M[2,2];c2=M[2,3]
  print(paste(a1,"x1 +",b1,"x2 =",c1))
  print(paste(a2,"x1 +",b2,"x2 =",c2))
}
showE(A)
print("Creating the corresponding augmented matrix")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showE(A)
print("By The Equation 1 x1 + 1 x2 = 1 it is clear that x1 = 1 - x2")
print("So x2 is free that means we are “free” to choose any value for x2")

