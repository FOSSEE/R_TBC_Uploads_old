### Page number 26
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(0,1,0,1,0,-3,-1,2,3,3,2,-9),ncol = 4)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4]
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4]
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 =",d1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 =",d2))
  print(paste(a3,"x1 +",b3,"x2 +",c3,"x3 =",d3))
}
showEqn(A)
print("Creating the corresponding augmented matrix")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
print("By The Equation 1 x1 + 0 x2 + 2 x3 = 2 it is clear that x1 = 2 - 2 x3")
print("And by The Equation 0 x1 + 1 x2 + -1 x3 = 3 it is clear that x2 = 3 + x3")
print("So x3 is free that means we are “free” to choose any value for x3")
print("As examples, x1 = 2, x2 = 3, x3 = 0 is one solution")

