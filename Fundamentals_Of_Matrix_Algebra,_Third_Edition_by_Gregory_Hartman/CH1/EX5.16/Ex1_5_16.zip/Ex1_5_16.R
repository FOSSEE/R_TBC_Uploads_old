### Page number 35
# By the conceptual method we got linear system of equation
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,2,1,-1,1,0,0,-1,1,0,-1,1,1,-1,0,1,100,0,10,0),ncol = 5)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];e1=M[1,5];
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];e2=M[2,5]
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4];e3=M[3,5]
  a4=M[4,1];b4=M[4,2];c4=M[4,3];d4=M[4,4];e4=M[4,5]
  
  print(paste(a1,"b +",b1,"g +",c1,"r +",d1,"y =",e1))
  print(paste(a2,"b +",b2,"g +",c2,"r +",d2,"y =",e2))
  print(paste(a3,"b +",b3,"g +",c3,"r +",d3,"y =",e3))
  print(paste(a4,"b +",b4,"g +",c4,"r +",d4,"y =",e4))
}
print("We got the linear system by conceptual method")
showEqn(A)
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
print("b = 20 ,g = 30 , r = 10 , y = 40")
print("we have 20 blue, 30 green, 10 red and 40 yellow marbles")

