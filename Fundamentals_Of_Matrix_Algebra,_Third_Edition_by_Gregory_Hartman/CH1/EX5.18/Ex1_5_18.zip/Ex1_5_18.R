### Page number 38
# By the conceptual method we got linear system of equation
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,2,1,-1,4,4),ncol = 3)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3]
  a2=M[2,1];b2=M[2,2];c2=M[2,3]
  
  print(paste(a1,"b +",b1,"r =",c1))
  print(paste(a2,"b +",b2,"r =",c2))
}
print("We got the linear system by conceptual method")
showEqn(A)
print("the corresponding augmented matrix is")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
A[,3] <- format(round(A[,3],2))
print(A)
showEqn(A)
#textbook uses only one digit after desimal
print("b = 2.67 , r = 1.33")
print("the speed of the boat = 2.67mph and speed of the river = 1.33mph")

