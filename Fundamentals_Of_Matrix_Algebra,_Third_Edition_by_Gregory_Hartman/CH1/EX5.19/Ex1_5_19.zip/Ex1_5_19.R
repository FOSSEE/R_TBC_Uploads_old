### Page number 39
# By the conceptual method we got linear system of equation
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,1,4,-1,1,2,1,1,1,6,2,3),ncol = 4)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4];
  
  print(paste(a1,"a +",b1,"b +",c1,"c =",d1))
  print(paste(a2,"a +",b2,"b +",c2,"c =",d2))
  print(paste(a3,"a +",b3,"b +",c3,"c =",d3))
}
print("We got the linear system by conceptual method")
showEqn(A)
print("the corresponding augmented matrix is")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
a <- A[1,4]
b <- A[2,4]
c <- A[3,4]
print("a = 1 , b = -2 , c = 3")
print(paste("y =",a,"x^2 +",b,"x +",c ))

