### Page number 40
# By the conceptual method we got linear system of equation
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,1,1,5,1,10,32,100),ncol = 4)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];
  
  print(paste(a1,"x +",b1,"y +",c1,"z =",d1))
  print(paste(a2,"x +",b2,"y +",c2,"z =",d2))
}
print("We got the linear system by conceptual method")
showEqn(A)
print("the corresponding augmented matrix is")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
print("From the first Equation 1 x + 0 y + -1.25 z = 15 it is clear that x = 15 + 1.25z")
print("From the Second Equation 0 x + 1 y + 2.25 z = 17 it is clear that y = 17 - 2.25z")
print("By both Equation , z is free so we have infinite solution")
print("To avoid fractions, z must be a multiple of 4 (−4, 0, 4, 8, . . .)")
print("so probably the “best” answer is that we have 20 $1 bills, 8 $5 bills and 4 $10 bills")
