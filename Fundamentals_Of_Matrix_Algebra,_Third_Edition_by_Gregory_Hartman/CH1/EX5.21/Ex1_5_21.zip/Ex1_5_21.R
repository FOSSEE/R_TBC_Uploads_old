### Page number 41
# By the conceptual method we got linear system of equation
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,6,1,1,1,-1,1,2,-1,1,3,0,7,24,0),ncol = 5)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];e1=M[1,5]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];e2=M[2,5]
  a3=M[3,1];b3=M[3,2];c3=M[3,3];d3=M[3,4];e3=M[3,5]
  
  print(paste(a1,"t +",b1,"x +",c1,"w +",d1,"f =",e1))
  print(paste(a2,"t +",b2,"x +",c2,"w +",d2,"f =",e2))
  print(paste(a3,"t +",b3,"x +",c3,"w +",d3,"f =",e3))
}
print("We got the linear system by conceptual method")
showEqn(A)
print("the corresponding augmented matrix is")
print(A)
print("putting the matrix into reduced row echelon form")
A <- pracma::rref(A)
print(A)
showEqn(A)
print("From the first Equation 1 t + 0 x + 0 w + 0.5 f = 3.5 it is clear that t = 3.5 - 0.5f")
print("From the Second Equation 0 t + 1 x + 0 w + 1 f = 4 it is clear that x = 4 - f")
print("From the third Equation 0 t + 0 x + 1 w + -0.5 f = -0.5 it is clear that w = 0.5(f-1)")
print("By all equations , f is free so we have infinite solution")
print("as Example at f = 3, then we 2 touchdowns, 1 extra point, 1 two point conversion,\n
and (of course) 3 field goals")
