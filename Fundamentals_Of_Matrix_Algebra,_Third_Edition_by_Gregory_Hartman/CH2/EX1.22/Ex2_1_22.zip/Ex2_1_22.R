### Page number 47
matrixAdd<-function()
{
A <- matrix(c(1,-1,5,2,2,5,3,1,5),ncol=3)
B <- matrix(c(2,1,-1,4,2,0,6,2,4),ncol = 3)
C <- matrix(c(1,9,2,8,3,7),ncol=3)
print(A+B)
print(B+A)
print(A-B)
print("A+C can not perform due to non-conformable arrays")
print(-3*A+2*B)
print(A-A)
print(5*A+5*B)
print(5*(A+B))
}
matrixAdd()


