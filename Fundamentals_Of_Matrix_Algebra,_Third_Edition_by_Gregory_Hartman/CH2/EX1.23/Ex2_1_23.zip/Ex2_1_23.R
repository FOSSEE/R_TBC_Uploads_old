### Page number 50
matrixExpr<-function()
{
  print("Let the given matrix is")
  A <- matrix(c(2,3,-1,6),ncol=2)
  print(A)
  print("We have to find matrix X in 2A + 3X = −4A")
  X <- (-4*A - 2*A)/3
  print("X is ")
  print(X)
}
matrixExpr()