### Page number 55
matrixMult <- function()
{
A <- matrix(c(1,3,2,4),ncol=2)
B <- matrix(c(1,2,-1,2,0,-1),ncol=3)
print("Multiplecation of A and B is ")
print(A%*%B)
}
matrixMult()