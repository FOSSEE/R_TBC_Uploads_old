### Page number 56
matrixMult <- function()
{
  A <- matrix(c(1,5,-2,-1,2,3),ncol=2)
  B <- matrix(c(1,2,1,6,1,7,1,9),ncol=4)
  print("AB =")
  print(A %*% B)
}
matrixMult()