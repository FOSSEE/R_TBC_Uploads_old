### Page number 57
matrixMult <- function()
{
  A <- matrix(c(2,9,3,8,4,7),ncol=3)
  B <- matrix(c(3,5,6,-1),ncol=2)
  print("AB =")
  tryCatch(print(A %*% B),finally = print("These matrix A2x3 and B2x2 can not be multiplied"))
}
matrixMult()