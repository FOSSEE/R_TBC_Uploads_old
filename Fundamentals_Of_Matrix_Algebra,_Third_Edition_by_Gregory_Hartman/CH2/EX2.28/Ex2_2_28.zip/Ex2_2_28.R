### Page number 57
vectorMult <- function()
{
  x <- c(-2,4,3)
  u <- t(c(1,2,3))
  print("xu =")
  print(x %*% u)
}
vectorMult()