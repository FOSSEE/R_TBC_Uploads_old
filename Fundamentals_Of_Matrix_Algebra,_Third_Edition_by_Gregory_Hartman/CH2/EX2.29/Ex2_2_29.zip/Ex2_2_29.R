### Page number 58
#We have to multiply matrices
matrixMult <- function()
{
A <- matrix(c(1,2,-2,2,-7,-8,3,5,3),ncol=3)
B <- matrix(1, ncol = 3,nrow = 3)
C <- matrix(c(1,2,0,0,1,2,2,0,1),ncol=3)
I <- diag(1,3)
O <- matrix(0,ncol=4,nrow=3)
print(A%*%B)
print(B%*%A)
print(A%*%O)
print(A%*%I)
print(I%*%A)
print(I%*%I)
print(B%*%C)
print(B%*%B)
}
matrixMult()