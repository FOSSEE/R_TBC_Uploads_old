### Page number 60
matrixExpr <- function()
{
  A <- matrix(c(1,3,2,4),ncol=2)
  B <- matrix(c(1,1,1,-1),ncol=2)
  C <- matrix(c(2,1,1,2),ncol=2)
  print("1. A(B + C)")
  print(A %*% (B+C))
  print("2. AB + AC")
  print(A %*% B + A %*% C)
  print("3. A(BC)")
  print(A %*% (B %*% C))
  print("4. (AB)C")
  print((A %*% B) %*% C)
}
matrixExpr()