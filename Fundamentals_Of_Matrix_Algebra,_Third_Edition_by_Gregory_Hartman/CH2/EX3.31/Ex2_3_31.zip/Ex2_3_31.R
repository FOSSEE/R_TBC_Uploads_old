### Page number 67
x <- c(1,-1)
y <- c(2,3)
z <- c(-3,2)
Text<-'x';Text1<-'y';Text2<-'z'
plot(x,xlim=c(-2,2),ylim = c(-2,2),type = 'n')
plot(y,xlim=c(-2,2),ylim = c(-2,2),type = 'n')
plot(z,xlim=c(-2,2),ylim = c(-2,2),type = 'n',ylab = 'y')
arrows(c(0,-1,2),c(-1,-1,-1),c(1,1,-1),c(-2,2,2),col = c('red','green','black'))
text(x=c(1.1,1.1,-1.1), y=c(-2,2,2), label=c(Text,Text1,Text2), srt=35)

