### Page number 68
x <- c(1,1)
y <- c(3,1)
Text<-'x';Text1<-'y';Text2<-'x+y'
plot(x,xlim=c(0,5),ylim = c(0,5),type = 'n')
plot(y,xlim=c(0,5),ylim = c(0,5),type = 'n')
plot(x+y,xlim=c(0,5),ylim = c(0,5),type = 'n',ylab = 'y')
arrows(c(0,0,0),c(0,0,0),c(1,3,4),c(1,1,2),col=c('red','green','black'))
text(x=c(1.1,4.2,3.1), y=c(1.1,2.2,1.1), label=c(Text,Text1,Text2), srt=35)
