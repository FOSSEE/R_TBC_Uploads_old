### Page number 70
x <- c(1,1)
y <- c(-3,2)
Text<-'x';Text1<-'y';Text2<-'3x';Text3 <-'-2x';Text4<-'1/2y'
plot(x,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(y,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(3*x,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(-2*x,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot((1/2)*y,xlim=c(-5,5),ylim = c(-2,5),type = 'n',ylab = 'y')

arrows(c(0,0,0,0,0),c(0,0,0,0,0),c(1,-3,3,-2,-1.5),c(1,2,3,-2,1),col=c('red','green','red','blue','green'))
text(x=c(1,-3.1,3.2,-2.1,-1.6), y=c(1.1,2.1,3.1,-2,1.1), label=c(Text,Text1,Text2,Text3,Text4), srt=35)
