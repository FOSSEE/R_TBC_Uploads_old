### Page number 71
x <- c(1,1)
y <- c(-3,2)
Text<-'x';Text1<-'y';Text2<-'-y';Text3 <-'x-y'
plot(x,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(y,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(-y,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(x-y,xlim=c(-5,5),ylim = c(-2,5),type = 'n',ylab = 'y')

arrows(c(0,0,0,0,1,3),c(0,0,0,0,1,-2),c(1,-3,3,4,4,4),c(1,2,-2,-1,-1,-1),col=c('red','green','green','black','blue','blue'))
text(x=c(1,-3.1,3.1,4.1), y=c(1.1,2.1,-2.1,-1.1), label=c(Text,Text1,Text2,Text3), srt=35)
