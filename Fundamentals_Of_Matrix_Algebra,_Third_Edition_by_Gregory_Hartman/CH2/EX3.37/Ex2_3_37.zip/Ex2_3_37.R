### Page number 72
x <- c(2,-2)
y <- c(2,2)
Text<-'x';Text1<-'y';Text2<-'x-y'
plot(x,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(y,xlim=c(-5,5),ylim = c(-2,5),type = 'n')
plot(x-y,xlim=c(-5,5),ylim = c(-2,5),type = 'n',ylab = 'y')
arrows(c(0,0,2),c(0,0,2),c(2,2,2),c(-2,2,-2),col=c('red','green','blue'))
text(x=c(2.1,2.1,2.2), y=c(-2.1,2.1,-1.7), label=c(Text,Text1,Text2), srt=35)
