### Page number 74
vecLength <- function()
{
  x1 <- c(1,1)
  x2 <- c(2,-3)
  x3 <- c(.6,.8)
  x4 <- c(3,0)
  l <- list(x1,x2,x3,x4)
  for (val in l){
    print("Length of vector =")
    print(sqrt(sum(val^2)))
  }
}
vecLength()