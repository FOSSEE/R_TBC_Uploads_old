### Page number 74
vecLength <- function()
{
  x <- c(2,-1)
    print("Length of vector = ||x||")
    print(sqrt(sum(x^2)))
    print("Length of vector = ||3x||")
    print(sqrt(sum((3*x)^2)))
    print("Length of vector = ||-2x||")
    print(sqrt(sum((-2*x)^2)))
    print("Length of vector = ||cx||")
    print(paste("|c|",sqrt(sum(x^2))))
}
vecLength()