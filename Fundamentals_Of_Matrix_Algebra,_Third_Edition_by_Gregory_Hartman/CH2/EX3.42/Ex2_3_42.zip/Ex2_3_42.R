### Page number 78
A <- matrix(c(1,1,-1,-1),ncol = 2)
x <- c(1,1)
y <- c(-1,1)
z <- c(4,1)
print(Ax <- A %*% x)
print(Ay <- A %*% y)
print(Az <- A %*% z)
#This is a unwanted warning
suppressWarnings('zero-length arrow is of indeterminate angle')
Text<-'x';Text1<-'y';Text2<-'z';Text3<-'Ax';Text4<-'Ay';Text5<-'Az'
plot(x,xlim=c(-5,5),ylim = c(-2,6),type = 'n')
plot(y,xlim=c(-5,5),ylim = c(-2,6),type = 'n')
plot(z,xlim=c(-5,5),ylim = c(-2,6),type = 'n')
plot(Ax,xlim=c(-5,5),ylim = c(-2,6),type = 'n')
plot(Ay,xlim=c(-5,5),ylim = c(-2,6),type = 'n')
plot(Az,xlim=c(-5,5),ylim = c(-2,6),type = 'n',ylab = 'y')
arrows(c(0,0,0,0,0,0),c(0,0,0,0,0,0),c(1,-1,4,0,-2,3),c(1,1,1,0,-2,3),col=c('red','green','blue','green4','hotpink','red'))
text(x=c(1.1,-1.1,4.1,0.1,-2.1,3.1), y=c(1.1,1.1,1.1,-0.4,-2.1,3.1), label=c(Text,Text1,Text2,Text3,Text4,Text5), srt=35)
