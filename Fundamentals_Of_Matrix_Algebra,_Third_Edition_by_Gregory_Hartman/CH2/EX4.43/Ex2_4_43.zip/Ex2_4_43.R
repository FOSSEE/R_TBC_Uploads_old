### Page number 81
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,-1,1,2,2,1,3,1,0),ncol = 3)
b <- c(5,-1,2)
print("The augmented matrix [A b] =")
X <- cbind(A,b)
print(X)

print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
x <- X[,4]
print('x =')
print(x)