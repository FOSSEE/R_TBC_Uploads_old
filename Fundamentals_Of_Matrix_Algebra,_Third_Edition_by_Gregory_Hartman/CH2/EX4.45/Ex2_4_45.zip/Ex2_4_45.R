### Page number 84
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(2,-2,-3,3),ncol = 2)
O <- c(0,0)
print("The augmented matrix [A O] =")
X <- cbind(A,O)
print(X)
showEqn <- function(M)
{
  a=M[1,1];b=M[1,2];c=M[1,3]
  print(paste(a,"x1 +",b,"x2 =",c))
}
print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
showEqn(X)
print("By the Equation it is clear that x1 = 1.5x2 so x2 is free")
#This is a conceptual method so we can't show it in program
print("so we replace the x1 in x with 1.5x2")
print("at the end we get x = x2 * v where v =")
print(v <- c(1.5,1))
plot(v,xlim=c(-3,3),ylim = c(0,3),type = 'n',ylab = 'y')
arrows(0,0,1.5,1,col = 'red')
Text='v'
text(x=1.6,y=1.1, label=Text, srt=35)
print('For instance, picking x2 = 2')
print(x <- c(3,2))
