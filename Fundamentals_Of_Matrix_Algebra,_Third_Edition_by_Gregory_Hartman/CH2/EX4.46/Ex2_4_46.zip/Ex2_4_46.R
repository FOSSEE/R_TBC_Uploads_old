### Page number 85
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,2,2,4),ncol = 2)
b <- c(3,6)
print("The augmented matrix [A b] =")
X <- cbind(A,b)
print(X)
showEqn <- function(M)
{
  a=M[1,1];b=M[1,2];c=M[1,3]
  print(paste(a,"x1 +",b,"x2 =",c))
}
print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
showEqn(X)
print("By the Equation it is clear that x1 = 3-2x2 so x2 is free")
#This is a conceptual method so we can't show it in program
print("so we replace the x1 in x with 3-2x2")
print("at the end we get x = xp + x2*v where xp and v =")
print(xp <- c(3,0))
print(v <- c(-2,1))
print('For instance, by letting x2 = −1, 0, or 2, we get the solutions')
print(x <- c(5,-1))
print(x <- c(3,0))
print(x <- c(-1,2))
plot(xp,xlim=c(-3,3),ylim = c(0,3),type = 'n')
plot(v,xlim=c(-3,3),ylim = c(0,3),type = 'n',ylab = 'y')
arrows(c(0,3),c(0,0),c(3,-2),c(0,1),col = c('red','green'))
Text<-'xp';Text1<-'v'
text(x=c(3.1,-2.1),y=c(0,1.1), label=c(Text,Text1), srt=35)

