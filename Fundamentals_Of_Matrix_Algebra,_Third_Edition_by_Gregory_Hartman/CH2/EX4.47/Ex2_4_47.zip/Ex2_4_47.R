### Page number 90
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,4,-1,2,1,4,3,6),ncol = 4)
b <- c(1,10)
O <- c(0,0)
print("We’ll tackle Ax=O first")
print("The augmented matrix [A O] =")
X <- cbind(A,O)
print(X)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];e1=M[1,5]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];e2=M[2,5]
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 +",d1,"x4 =",e1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 +",d2,"x4 =",e2))
}
print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
showEqn(X)
print("By the Equation it is clear that x1 = -x3 - 2x4")
print("and by second equation x2 = x4 so x3 and x4 are free")
#This is a conceptual method so we can't show it in program
print("So at the end we get x = x3u + x4v where u and v are")
print(u <- c(-1,0,1,0));print(v <- c(-2,1,0,1))

####for second question
print("Now let’s tackle Ax = b")
print("The augmented matrix [A b] =")
Y <- cbind(A,b)
print(Y)
print("putting the matrix into reduced row echelon form")
Y <- pracma::rref(Y)
print(Y)
showEqn(Y)
print("By the Equation it is clear that x1 = 2 − x 3 − 2x 4")
print("and by second equation x2 =1 + x4 so x3 and x4 are free")
#This is a conceptual method so we can't show it in program
print("So at the end we get x = xp + x3u + x4v where xp , u and v are")
print(xp <- c(2,1,0,0));print(u <- c(-1,0,1,0));print(v <- c(-2,1,0,1))


