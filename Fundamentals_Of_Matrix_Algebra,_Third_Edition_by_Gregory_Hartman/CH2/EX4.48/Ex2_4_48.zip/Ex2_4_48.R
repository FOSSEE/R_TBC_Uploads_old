### Page number 92
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,3,2,4,-3,5,2,2,7,3),ncol = 5)
b <- c(2,-4)
X <- cbind(A,b)
showEqn(X)
print("The augmented matrix [A b] =")

print(X)
showEqn <- function(M)
{
  a1=M[1,1];b1=M[1,2];c1=M[1,3];d1=M[1,4];e1=M[1,5];f1=M[1,6]
  a2=M[2,1];b2=M[2,2];c2=M[2,3];d2=M[2,4];e2=M[2,5];f2=M[2,6]
  print(paste(a1,"x1 +",b1,"x2 +",c1,"x3 +",d1,"x4 +",e1,"x5 =",f1))
  print(paste(a2,"x1 +",b2,"x2 +",c2,"x3 +",d2,"x4 +",e2,"x5 =",f2))
}
print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
showEqn(X)
print("By the Equation it is clear that x1 = −8 − 11x3 + 2x4 + 11x5")
print("and by second equation x2 = 5 + 7x3 − 2x4 − 9x5 so x3,x4 and x5 are free")
#This is a conceptual method so we can't show it in program
print("So at the end we get x =xp + x3u + x4v + x5w where xp, u , v and w are")
print(xp <- c(-8,5,0,0,0));print(u <- c(-11,7,1,0,0));print(v <- c(2,-2,0,1,0))
print(w <- c(11,-9,0,0,1))


