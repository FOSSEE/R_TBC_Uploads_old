### Page number 94
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,4,2,5),ncol = 2)
b <- c(3,6)
X <- cbind(A,b)
print("The augmented matrix [A b] =")
print(X)
print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
x <- X[,3]
print("so x =")
print(x)
print("Ax = 0 has only one solution")


