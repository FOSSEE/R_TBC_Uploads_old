### Page number 94
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,2,1,2),ncol = 2)
b <- c(1,1)
X <- cbind(A,b)
print("The augmented matrix [A b] =")
print(X)
print("putting the matrix into reduced row echelon form")
X <- pracma::rref(X)
print(X)
showEqn <- function(M)
{
  a=M[1,1];b=M[1,2];c=M[1,3]
  print(paste(a,"x1 +",b,"x2 =",c))
}
showEqn(X)
print("By Equation one x1 = -x2 so x2 is free")
print("at the end we get x = x2u where u =")
print(u <- c(-1,1))
print("We have no solution to Ax = b,but infinite solutions to Ax=O")


