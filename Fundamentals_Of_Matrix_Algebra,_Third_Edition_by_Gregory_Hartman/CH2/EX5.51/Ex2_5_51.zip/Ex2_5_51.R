### Page number 98
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,5,-1,3),ncol = 2)
B <- matrix(c(-8,32,-13,-17,1,21),ncol = 3)
Y <- cbind(A,B)
print("The augmented matrix [A B] =")
print(Y)
print("putting the matrix into reduced row echelon form")
Y <- pracma::rref(Y)
print(Y)
X <- Y[,3:5]
print(X)


