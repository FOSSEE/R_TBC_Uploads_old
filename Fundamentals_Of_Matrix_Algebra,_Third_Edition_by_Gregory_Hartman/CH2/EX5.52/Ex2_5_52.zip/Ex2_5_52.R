### Page number 99
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(1,0,2,0,-1,-1,2,-2,0),ncol = 3)
B <- matrix(c(-1,2,2,2,-6,-4),ncol = 2)
Y <- cbind(A,B)
print("The augmented matrix [A B] =")
print(Y)
print("putting the matrix into reduced row echelon form")
Y <- pracma::rref(Y)
print(Y)
X <- Y[,4:5]
print(X)


