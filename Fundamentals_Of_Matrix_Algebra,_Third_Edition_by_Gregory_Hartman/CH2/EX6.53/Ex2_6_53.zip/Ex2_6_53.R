### Page number 104
###For run this code install pracma package
### by using command install.packages("pracma")

A <- matrix(c(2,1,1,1),ncol = 2)
I <- matrix(c(1,0,0,1),ncol=2)
Y <- cbind(A,I)
print("The augmented matrix [A I] =")
print(Y)
print("putting the matrix into reduced row echelon form")
Y <- pracma::rref(Y)
print(Y)
X <- Y[,3:4]
print(X)
print("To Check our work")
print(A%*%X)



