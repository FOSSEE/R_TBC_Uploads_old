### page no 107
###For run this code install pracma package
### by using command install.packages("pracma")
A <- matrix(c(1,1,1,1,-1,2,-1,1,3),ncol = 3)
inverseFun <- function(M)
{
  I <- matrix(c(1,0,0,0,1,0,0,0,1),ncol=3)
  Y <- cbind(M,I)
  print("The augmented matrix [A I] =")
  print(Y)
  print("putting the matrix into reduced row echelon form")
  Y <- pracma::rref(Y)
  print(Y)
  X <- Y[,4:6]
  print("Inverse of matrix is")
  print(X)
}
inverseFun(A)


