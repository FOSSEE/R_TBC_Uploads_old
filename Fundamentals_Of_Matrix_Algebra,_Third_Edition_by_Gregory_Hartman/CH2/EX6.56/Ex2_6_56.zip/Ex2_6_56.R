### page no 108
A <- matrix(c(3,-1,2,9),ncol = 2)
inverseFun <- function(M)
{
  print("Inverse of matrix is")
  print(solve(M))
}
inverseFun(A)