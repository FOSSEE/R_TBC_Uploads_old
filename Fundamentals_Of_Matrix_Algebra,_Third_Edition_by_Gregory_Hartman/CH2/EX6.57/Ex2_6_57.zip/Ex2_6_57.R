### page no 110
A <- matrix(c(1,-3,4,0,-4,-5,-3,10,-11),ncol = 3)
b <- c(-15,57,-46)
inverseFun <- function(M)
{
  print("Inverse of matrix is")
  print(solve(M))
}
print("A^-1 =")
inverseFun(A)
x <- inverseFun(A) %*% b
print("x =")
print(x)
