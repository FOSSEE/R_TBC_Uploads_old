### page no 122
transposeMatrix <- function()
{
  A <- matrix(c(1,4,2,5,3,6),ncol = 3)
  print("A =")
  print(A)
  print("Transpose of A =")
  print(t(A))
}
transposeMatrix()