### page no 122
transposeMatrix <- function()
{
  A <- matrix(c(7,2,-5,2,-1,3,9,3,0,1,0,11),ncol = 4)
  B <- matrix(c(1,3,4,10,-5,2,-2,7,-3),ncol = 3)
  C <- matrix(c(1,-1,7,8,3),ncol=5)
  l <- list(A,B,C)
  for(val in l){
    print("Transpose of matrices")
    print(t(val))
  }
}
transposeMatrix()