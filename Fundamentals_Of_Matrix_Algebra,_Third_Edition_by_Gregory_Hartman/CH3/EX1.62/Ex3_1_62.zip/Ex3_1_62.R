### page no 123
transposeMatrix <- function()
{
  A <- matrix(c(1,0,0,2,4,0,3,5,6),ncol = 3)
  B <- matrix(c(3,0,0,0,7,0,0,0,-1),ncol = 3)
  C <- matrix(c(1,0,0,0,2,4,0,0,3,5,6,0),ncol=3)
  I <- diag(c(1,1,1,1))
  
  l <- list(A,B,C,I,t(A),t(B),t(C),t(I))
  for(val in l){
    print("Diagonal of matrices")
    print(diag(val))
  }
  print("A is upper triangular,t(A) is lower triangular")
  print("B and I are diagonal means both upper and lower triangular")
  print("C is upper triangular,t(C) is lower triangular")
  
}
transposeMatrix()