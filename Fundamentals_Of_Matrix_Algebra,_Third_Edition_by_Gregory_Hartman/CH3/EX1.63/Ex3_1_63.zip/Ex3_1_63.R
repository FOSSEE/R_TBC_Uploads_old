### page no 124
A <- matrix(c(1,4,2,5,3,6),ncol=3)
B <- matrix(c(1,3,2,-1,1,0),ncol = 3)
print("t(A)+t(B)")
print(t(A)+t(B))
print("t(A+B)")
print(t(A+B))