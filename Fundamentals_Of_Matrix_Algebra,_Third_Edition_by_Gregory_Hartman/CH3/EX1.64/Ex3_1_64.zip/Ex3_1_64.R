### page no 124
A <- matrix(c(1,3,2,4),ncol=2)
B <- matrix(c(1,1,2,0,-1,1),ncol = 3)
print("t(AB)")
print(t(A%*%B))
print("t(A) %*% t(B) can not perform due to  non-conformable arguments")
print("t(B) %*% t(A)")
print(t(B) %*% t(A))