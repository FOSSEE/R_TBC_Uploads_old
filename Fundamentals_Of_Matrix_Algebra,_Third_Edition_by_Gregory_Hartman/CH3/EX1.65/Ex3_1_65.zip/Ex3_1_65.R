### page no 125
A <- matrix(c(2,1,7,4),ncol=2)
print(t(solve(A)))
print(solve(t(A)))