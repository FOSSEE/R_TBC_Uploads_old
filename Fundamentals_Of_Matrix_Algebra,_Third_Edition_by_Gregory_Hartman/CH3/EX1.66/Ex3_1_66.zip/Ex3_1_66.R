### page no 127
A <- matrix(c(2,2,1,1,-1,0,3,1,1),ncol = 3)
print(A %*% t(A))
print(A + t(A))
print(A - t(A))