### page no 131
A <- matrix(c(1,3,2,4),ncol = 2)
B <- matrix(c(1,3,-2,2,8,7,0,1,-5),ncol = 3)
C <- matrix(c(1,4,2,5,3,6),ncol = 3)
I <- diag(c(1,1,1,1))
print("here matrix C is not a Squre matrix so we can't find its trace")
#Here m1,m2,m3,m4 are formal parameters
tr <- function(m1,m2,m3)
{
  l <- list(m1,m2,m3)
  for(val in l)
    {
    print("trace of matrices")
    print(sum(diag(val)))
  }
}
tr(A,B,I)