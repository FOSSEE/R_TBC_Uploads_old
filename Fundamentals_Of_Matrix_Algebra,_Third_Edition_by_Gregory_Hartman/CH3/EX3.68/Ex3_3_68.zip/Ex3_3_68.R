### page no 137
#Computation of determinants
A <- matrix(c(1,3,2,4),ncol = 2)
B <- matrix(c(3,2,-1,7),ncol = 2)
C <- matrix(c(1,-2,-3,6),ncol = 2)
print("determinant of A:")
print(det(A))
print("determinant of B:")
print(det(B))
print("determinant of C:")
print(det(C))
