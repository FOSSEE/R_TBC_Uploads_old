### page no 137
A <- matrix(c(1,4,7,2,5,8,3,6,9),ncol = 3)
B <- matrix(c(1,-3,-1,1,2,5,9,1,0,7,-4,1,8,2,6,1),ncol = 4)
A13 <- det(A[-1,-3])
C13 <- ((-1)^(1+3))*A13
print(paste("A 1,3 =",A13,"Cofactor =",C13))
A32 <- det(A[-3,-2])
C32 <- ((-1)^(3+2))*A32
print(paste("A 3,2 =",A32,"Cofactor =",C32))
print("According to book No solution at this time for B")
#B21 <- det(B[-2,-1])
#C21 <- ((-1)^(2+1))*B21
#print(paste("B 2,1 =",B21,"Cofactor =",C21))
#B43 <- det(B[-4,-3])
#C43 <- ((-1)^(4+3))*B43
#print(paste("B 4,3 =",B43,"Cofactor =",C43))