### page no 139
A <- matrix(c(1,4,7,2,5,8,3,6,9),ncol = 3)
C21 <- ((-1)^(2+1))*det(A[-2,-1])
C22 <- ((-1)^(2+2))*det(A[-2,-2])
C23 <- ((-1)^(2+3))*det(A[-2,-3])
a21=4;a22=5;a23=6
print("cofactor expansion along the second row")
print("a 2,1 C 2,1 + a 2,2 C 2,2 + a 2,3 C 2,3")
print(a21 * C21 + a22 * C22 + a23 * C23)
print("cofactor expansion down the first column")
C11 <- ((-1)^(1+1))*det(A[-1,-1])
C21 <- ((-1)^(2+1))*det(A[-2,-1])
C31 <- ((-1)^(3+1))*det(A[-3,-1])
a11=1;a21=4;a31=7
print("a 1,1 C 1,1 + a 2,1 C 2,1 + a 3,1 C 3,1")
print(as.integer(a11 * C11 + a21 * C21 + a31 * C31))


