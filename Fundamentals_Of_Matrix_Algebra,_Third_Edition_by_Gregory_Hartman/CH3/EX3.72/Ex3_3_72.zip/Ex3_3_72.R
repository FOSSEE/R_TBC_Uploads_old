### page no 142
A <- matrix(c(3,0,3,6,2,-1,7,-1,1),ncol = 3)
a11=3;a12=6;a13=7
C11 <- ((-1)^(1+1))*det(A[-1,-1])
C12 <- ((-1)^(1+2))*det(A[-1,-2])
C13 <- ((-1)^(1+3))*det(A[-1,-3])
print("The cofactor expansion along the first row is")
print("det(A) = a 1,1 C 1,1 + a 1,2 C 1,2 + a 1,3 C 1,3")
print(paste("det(A) =",a11 * C11 + a12 * C12 + a13 * C13))

