### page no 142
A <- matrix(c(1,-1,8,5,2,2,5,9,1,3,-3,-6,2,4,1,3),ncol = 4)
a11=1;a12=2;a13=1;a14=2
C11 <- ((-1)^(1+1))*det(A[-1,-1])
C12 <- ((-1)^(1+2))*det(A[-1,-2])
C13 <- ((-1)^(1+3))*det(A[-1,-3])
C14 <- ((-1)^(1+4))*det(A[-1,-4])
print("The cofactor expansion along the first row is")
print("det(A) = a 1,1 C 1,1 + a 1,2 C 1,2 + a 1,3 C 1,3 + a 1,4 C 1,4")
print(paste("det(A) =",a11 * C11 + a12 * C12 + a13 * C13 + a14 * C14,"= 60"))


