### page no 147
A <- matrix(c(1,2,7,-4,2,-3,2,1,0,0,3,0,9,5,8,2),ncol = 4)
a13=0;a23=0;a33=3;a43=0
C13 <- ((-1)^(1+3))*det(A[-1,-3])
C23 <- ((-1)^(2+3))*det(A[-2,-3])
C33 <- ((-1)^(3+3))*det(A[-3,-3])
C43 <- ((-1)^(4+3))*det(A[-4,-3])
print("The cofactor expansion along the first row is")
print("det(A) = a 1,3 C 1,3 + a 2,3 C 2,3 + a 3,3 C 3,3 + a 4,3 C 4,3")
print(paste("det(A) =",a13 * C13 + a23 *C23 + a33 *C33 + a43 * C43))


