### page no 147
A <- matrix(c(1,0,0,0,0,2,6,0,0,0,3,7,10,0,0,4,8,11,13,0,5,9,12,14,15),ncol = 5)
#Book uses same method with lengthy style
print(det(A))
