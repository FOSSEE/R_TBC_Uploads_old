### page no 149
A <- matrix(c(1,3,2,4),ncol = 2)
R1 <- A[1,]
R2 <- A[2,]
first <- function()
{print("opeartion 2R1 + R2 → R2")
R2 <- 2*R1 + R2
B <- rbind(R1,R2)
print(paste("determinant of B =",det(B)))
}
second <- function()
{print("opeartion 5R1 → R1")
R1 <- 5 * R1
B <- rbind(R1,R2)
print(paste("determinant of B =",det(B)))
}
third <- function()
{print("opeartion R1 ↔ R2")
R1 = R1 + R2
R2 = R1 - R2
R1 = R1 - R2
B <- rbind(R1,R2)
print(paste("determinant of B =",det(B)))
}
first()
second()
third()