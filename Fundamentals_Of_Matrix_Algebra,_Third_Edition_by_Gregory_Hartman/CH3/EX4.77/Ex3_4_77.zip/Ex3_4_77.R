### page no 150
A <- matrix(c(1,0,1,2,1,1,1,1,1),ncol = 3)
print(paste("determinant of A =",det(A)))
print("operation R1 ↔ R2 followed by R1 ↔ R3")
deterB <- -1*-1*det(A)
print(paste("determinant of B =",deterB))
print("operation 7 * R3 → R3")
deterC <- 7 * det(A)
print(paste("determinant of C =",deterC))
print("operation −3R2 +R1 → R1")
deterD <- det(A)
print(paste("determinant of D =",deterD))

      