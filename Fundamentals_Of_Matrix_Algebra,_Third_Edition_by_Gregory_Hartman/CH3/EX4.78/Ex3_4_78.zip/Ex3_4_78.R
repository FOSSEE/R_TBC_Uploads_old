### page no 151
A <- matrix(c(2,-1,3,4,-2,2,-2,5,1),ncol = 3)
R1 <- A[1,]/2
R2 <- R1 + A[2,]
R3 <- (-3) * R1 + A[3,]
R2 = R2 + R3
R3 = R2 - R3
R2 = R2 - R3
B <- rbind(R1,R2,R3)
print(paste("determinant of B =",det(B)))
print(paste("determinant of A =",det(A)))