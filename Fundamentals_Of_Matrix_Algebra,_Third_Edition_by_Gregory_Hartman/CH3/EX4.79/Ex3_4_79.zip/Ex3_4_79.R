### page no 152
B <- matrix(c(1,0,0,2,4,0,3,5,6),ncol = 3)
d <- det(B)
#lets find A 
print("we see that only the first three have an effect on the determinant so")
#Here s is deter,inant of A
s <- d /(2 * (1/3) * (-1))
print(paste("determinant of A =",s))

