### page no 153
A <- matrix(c(1,3,2,4),ncol = 2)
B <- matrix(c(2,3,1,5),ncol = 2)
print(paste("det(A) =",det(A)))
print(paste("det(B) =",det(B)))
print(paste("det(A+B) =",det(A+B)))
print(paste("det(3A) =",det(3*A)))
print(paste("det(AB) =",det(A %*% B)))
print(paste("det(t(A)) =",det(t(A))))
print(paste("det(A^-1) =",det(solve(A))))
#No solution given for comparision of trace and matrices