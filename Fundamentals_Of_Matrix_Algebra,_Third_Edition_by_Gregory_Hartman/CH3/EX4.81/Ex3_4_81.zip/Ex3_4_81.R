### page no 156
A <- matrix(c(1,-2,-5,3,3,7,9,4,2),ncol = 3)
print("Determinant of A")
print(det(A))