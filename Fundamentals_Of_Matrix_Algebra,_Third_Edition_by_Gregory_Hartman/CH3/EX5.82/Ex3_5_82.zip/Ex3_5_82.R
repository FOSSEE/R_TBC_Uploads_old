### page no 159
A <- matrix(c(1,1,2,5,4,-1,-3,2,0),ncol = 3)
b <- c(-36,-11,7)
#we have to apply cramers rule
c <- det(A)
p <- A[,1]
q <- A[,2]
r <- A[,3]
#for A1(b)
A[,1] <- b
x1 = det(A) / c
A[,1] <- p
#for A2(b)
A[,2] <- b
x2 = det(A) / c
A[,2] <- q
#for A3(b)
A[,3] <- b
x3 = det(A) / c
A[,3] <- p
print(rbind(x1,x2,x3))
