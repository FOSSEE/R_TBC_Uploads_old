### page no 160
#Cramer’s Rule
A <- matrix(c(1,3,2,4),ncol=2)
b <- c(-1,1)
c <- det(A)
cramers <- function(M,v)
{
c <- det(M)
A1b <- det(cbind(v,M[,-1]))
A2b <- det(cbind(M[,-2],v))
x1 <- A1b / c
x2 <- A2b / c
print(rbind(x1,x2))
}
cramers(A,b)