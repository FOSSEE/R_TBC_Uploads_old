### page no 166
A <- matrix(c(1,2,4,3),ncol = 2)
print("Eigen Values are")
print(eigen(A , only.values = TRUE))