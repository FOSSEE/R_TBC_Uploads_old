### page no 167
#To use this code use  pracma::rref()
#By using the command install.packages(pracma)
A <- matrix(c(1,2,4,3),ncol = 2)
I <- matrix(c(1,0,0,1),ncol = 2)
O >- c(0,0)
print("To find Ax = 5x we have to find (A-5I)x = 0") 
print(X <- A - 5*I)
print("the augmented matrix =")
print(Y <- cbind(X,O))
print("put augmented matrix into reduced row echelon form")
print(Z <- pracma::rref(Y))
showEqn <- function(M)
{
  a=M[1,1];b=M[1,2];c=M[1,3]
  print(paste(a,"x1 +",b,"x2 =",c))
}
showEqn(Z)
print("By equation x1 = x2 so x2 is free")
print("x =")
print(x <- c(1,1))
print("We have infinite solutions to the equation Ax = 5x")
print("Any nonzero scalar multiple of the vector c(1,1) is a solution")
