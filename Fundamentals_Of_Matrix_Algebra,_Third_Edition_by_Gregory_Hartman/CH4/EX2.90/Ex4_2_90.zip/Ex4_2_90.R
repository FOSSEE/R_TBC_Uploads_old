### page no 178
A <- matrix(c(1,0,0,2,4,0,3,5,6),ncol = 3)
print("Eigen value of matrix are")
print(eigen(A,only.values = TRUE))