### page no 178
A <- matrix(c(-3,3,15,9),ncol = 2)
B <- matrix(c(-7,-3,-6,-2,2,-2,10,3,9),ncol = 3)
# Answer may be differ due to conceptual and mathmatical work
print("1. eigenvalues and eigenvectors of A and B")
print(eigen(A))
print(eigen(B))
print("2. eigenvalues and eigenvectors of A^ −1 and B^ −1")
print(eigen(solve(A)))
print(eigen(solve(B)))
print("3. eigenvalues and eigenvectors of t(A)  and t(B) ")
print(eigen(t(A)))
print(eigen(t(B)))
print("4. The trace of A and B")
tr <- function(M)
{
  return(sum(diag(M)))
}
print(tr(A))
print(tr(B))
print("5. The determinant of A and B")
print(det(A))
print(det(B))
