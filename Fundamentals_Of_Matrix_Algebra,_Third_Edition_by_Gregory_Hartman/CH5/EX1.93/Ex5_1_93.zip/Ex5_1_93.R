### page no 188
A <- matrix(c(1,2,4,3),ncol = 2)
print("The four corners of the unit square that are represented by columns of B")
B <- cbind(c(0,0),c(1,0),c(1,1),c(0,1))
print(B)
print("Multiplying B by A gives the vectors")
print(A%*%B)
plot(B,xlim = c(0,5),ylim=c(0,5),type = 'n')
plot(A%*%B,xlim = c(0,5),ylim=c(0,5),type = 'n',ylab = 'y',xlab = 'x',
     main = 'Transforming the unit square by matrix multiplication')
segments(c(0,1,1,0),c(0,0,1,1),c(1,1,0,0),c(0,1,1,0),col = 'red')
segments(c(0,1,5,4),c(0,2,5,3),c(1,5,4,0),c(2,5,3,0),col = 'green')

