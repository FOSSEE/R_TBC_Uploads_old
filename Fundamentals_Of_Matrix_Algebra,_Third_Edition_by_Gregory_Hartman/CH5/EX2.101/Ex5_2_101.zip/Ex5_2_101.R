### page no 211
e1 <- c(1,0,0,0)
e2 <- c(0,1,0,0)
e3 <- c(0,0,1,0)
e4 <- c(0,0,0,1)
#total # hits = # of singles + # of doubles + # of triples + # of home runs
#total # bases = # of singles + 2×# of doubles + 3×# of triples + 4×# of home runs
print("Let x1 = # of singles , x2 = # of doubles , x3 = # of triples , x4 = # of home runs")
print("y1 = total # hits, y2 = total # bases")
T <- function(v)
{
  x1 <- v[1]; x2 <- v[2] ; x3 <- v[3] ; x4 <- v[4]
  y1 <- x1 + x2 + x3 + x4
  y2 <- x1 + 2 * x2 + 3 * x3 + 4 * x4
  return(c(y1,y2))
}
print("T(e1) =")
print(T(e1))
print("T(e2) =")
print(T(e2))
print("T(e3) =")
print(T(e3))
print("T(e4) =")
print(T(e4))
A <- cbind(T(e1),T(e2),T(e3),T(e4))
print("[T] = A =")
print(A)
print("Let’s check this. Consider the vector")
print(x <- c(1,2,3))
print("T(x) =")
print(T(x))
print("As an example, consider a player who had 102 singles, 30 doubles, 8 triples and 14
home runs. By using A, we find that")
x <- c(102,30,8,14)
print("Ax =")
print(A %*% x)
print("the player had 154 hits and 242 total base")