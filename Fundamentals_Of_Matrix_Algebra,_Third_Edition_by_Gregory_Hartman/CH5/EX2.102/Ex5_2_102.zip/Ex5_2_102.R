### page no 213
#### This is a conceptual question 

print("T1 is not linear due to 0 does not get mapped to 0")
print("T2 is also not linear. We cannot divide variables, nor can we put variabless 
      inside the square root function")
print("T3 is linear. Recall that 7 and π are just numbers, just coefficients")