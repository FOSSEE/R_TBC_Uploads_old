### page no 204
print("We’ll arbitrarily pick two vectors")
x <- c(3,-2)
y <- c(1,5)

T <- function(v)
{
  x1 <- v[1];x2 <- v[2]
  return(c(x1^2,2*x1,x1*x2))
}
print("T(x) =")
print(T(x))
print("T(y) =")
print(T(y))
print("T(x+y) =")
print(T(x+y))
ifelse((T(x+y) - T(x) + T(y)==0),print("T is a linear transformation"),
       print("T is not a linear transformation"))