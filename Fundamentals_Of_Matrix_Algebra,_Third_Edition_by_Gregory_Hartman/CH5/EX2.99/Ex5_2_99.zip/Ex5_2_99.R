### page no 205
A <- matrix(c(1,3,2,4),ncol = 2)
print("We’ll arbitrarily pick two vectors")
x <- c(3,-2)
y <- c(1,5)

T <- function(v)
{
  return(c(A %*% v))
}
print("T(x) =")
print(T(x))
print("T(y) =")
print(T(y))
print("T(x+y) =")
print(T(x+y))
ifelse(T(x+y) - (T(x) + T(y))== 0 , print("T is a linear transformation"),
       print("T is not a linear transformation"))