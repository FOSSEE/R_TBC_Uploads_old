### page no 217
#### We are using hand written method to draw
####This is not have accurate mathematics
v <- c(-3,-1,2)
plot(v,type = 'n',xlim = c(-5,5),ylim = c(-5,5),ylab = '')
grid(nx=10,ny=10)
arrows(c(0,0,0),c(0,0,0),c(0,5,-5),c(5,0,-5))
segments(c(0,3,2),c(0,3,3),c(3,2,2),c(3,3,5),lwd = 3,lty = 2)
arrows(0,0,2,5)
Text='z';Text1='y';Text2='x'
text(c(0,5.1,-5.1),c(5.1,0,-5.1),labels = c(Text,Text1,Text2))

