### page no 220
#### We are using hand written method to draw
####This is not have accurate mathematics

v <- c(2,1,3)
u <- c(1,3,-1)
print(v-u)
#for v
plot(v,type = 'n',xlim = c(-5,5),ylim = c(-5,5))
plot(u,type = 'n',xlim = c(-5,5),ylim = c(-5,5))
plot(v-u,type = 'n',xlim = c(-5,5),ylim = c(-5,5),ylab = '')
grid(nx=10,ny=10)
arrows(c(0,0,0),c(0,0,0),c(0,5,-5),c(5,0,-5))
segments(c(0,-2,-1),c(0,-2,-2),c(-2,-1,-1),c(-2,-2,1),lwd = 3,lty = 2)
arrows(0,0,-1,1)
Text='z';Text1='y';Text2='x'
text(c(0,5.1,-5.1),c(5.1,0,-5.1),labels = c(Text,Text1,Text2))
#for u
segments(c(0,-1,2),c(0,-1,-1),c(-1,2,2),c(-1,-1,-2),lwd = 3,lty = 2)
arrows(0,0,2,-2)
#for v-u
segments(c(0,-1,-3),c(0,-1,-1),c(-1,-3,-3),c(-1,-1,3),lwd = 3,lty = 2)
arrows(0,0,-3,3)
