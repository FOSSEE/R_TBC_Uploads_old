### page no 221
#### We are using hand written method to draw
####This is not have accurate mathematics

u <- c(-2,1,-1)
v <- c(2,-2,5)
print(v+u)
print(v-u)
#for u
plot(u,type = 'n',xlim = c(-5,5),ylim = c(-5,5))
plot(v,type = 'n',xlim = c(-5,5),ylim = c(-5,5),ylab = '')
grid(nx=10,ny=10)
arrows(c(0,0,0),c(0,0,0),c(0,5,-5),c(5,0,-5))
segments(c(0,2,1),c(0,2,2),c(2,1,1),c(2,2,1),lwd = 3,lty = 2)
arrows(0,0,1,1)
Text='z';Text1='y';Text2='x'
text(c(0,5.1,-5.1),c(5.1,0,-5.1),labels = c(Text,Text1,Text2))
#for v
segments(c(0,-2,-2),c(0,-2,-2),c(-2,-2,-2),c(-2,-2,3),lwd = 3,lty = 2)
arrows(0,0,-2,3)
#for u+v
arrows(-2,3,-1,4,col = 'gray')
#for u-v
arrows(0,0,-1,4,lty = 2,lwd = 2)
