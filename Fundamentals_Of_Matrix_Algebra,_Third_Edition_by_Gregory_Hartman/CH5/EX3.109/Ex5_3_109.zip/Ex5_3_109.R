### page no 222
#### We are using hand written method to draw
####This is not have accurate mathematics

v <- c(1,2,3)
print(2*v)
print(-v)

plot(v,type = 'n',xlim = c(-5,5),ylim = c(-5,5))
plot(2*v,type = 'n',xlim = c(-5,5),ylim = c(-5,5))
plot(-v,type = 'n',xlim = c(-5,5),ylim = c(-5,5),ylab = '')
grid(nx=10,ny=10)
arrows(c(0,0,0),c(0,0,0),c(0,5,-5),c(5,0,-5))
segments(c(0,-1,1),c(0,-1,-1),c(-1,1,1),c(-1,-1,2),lwd = 3,lty = 2)
arrows(0,0,1,2,col = 'green')
Text='z';Text1='y';Text2='x'
text(c(0,5.1,-5.1),c(5.1,0,-5.1),labels = c(Text,Text1,Text2))
#for 2v
segments(c(0,-2,2),c(0,-2,-2),c(-2,2,2),c(-2,-2,4),lwd = 3,lty = 2)
arrows(0,0,2,4,col = 'green',lwd = 3)
#for -v
segments(c(0,1,-1),c(0,1,1),c(1,-1,-1),c(1,1,-2),lwd = 3,lty = 2)
arrows(0,0,-1,-2,col = 'red',lwd = 3)
