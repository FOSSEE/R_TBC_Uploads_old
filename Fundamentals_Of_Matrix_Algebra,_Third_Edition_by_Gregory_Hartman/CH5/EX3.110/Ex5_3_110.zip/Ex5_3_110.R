### page no 225
v <- c(2,-3,5)
u <- c(-4,7,0)
vectorLength <- function()
{
  print("||v|| =")
  print(sqrt(sum(v^2)))
  print("||u||")
  print(sqrt(sum(u^2)))
}
vectorLength()