#1_1.R
#Page Number 4
#Example Number on page is Example 1
#A,B are 2 point.
#C is the endpoint of the vector from origin and parallel to AB.
A <-c(2,0,-1)
B <-c(4,5,3)
C=B-(-A) #Coordinates of point C.
#Let A,B,C be three noncollinear points in space.
u=B-A #Vector beginning at A and Ending at B.
v=C-A #Vector beginnifn at A and ending at C.
#Equation of plane containg Three points
s=1
t=1
x=A+s*u+t*v
paste(print(x),"is the general equation of any point in that plane.",sep = " ",collapse = NULL)


