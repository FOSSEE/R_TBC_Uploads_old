#1_12.R
#page Number 18
#question number on page is Example 3
#Let A be a Diagonal Square Matrix.
A <-matrix(c(25,0,0,0,20,0,0,0,30), nrow = 3, ncol = 3,byrow = TRUE)
print("The Example Above is a Diagonal Matrix")
print("A Diagonal Matrix is one where all elements other than at i=j are 0.")
print(A)
