#1_13.R
#page Number 18
#question number on page is Example 4
#Let A be a Diagonal Square Matrix.
A <-matrix(c(25,0,0,0,20,0,0,0,30), nrow = 3, ncol = 3,byrow = TRUE)
#trace is the sum of diagonal elements of a diagonal matrix.
#let trc be trace of the Matrix.
trc<-0
for (i in 1:nrow(A)){
  for (j in 1:ncol(A)){
    if (i==j){
      trc=trc+A[i,j]
    }
  }
}
#Outputting of Trace.
paste("The Trace of the given Matrix is",trc,sep = " ",collapse = NULL)
