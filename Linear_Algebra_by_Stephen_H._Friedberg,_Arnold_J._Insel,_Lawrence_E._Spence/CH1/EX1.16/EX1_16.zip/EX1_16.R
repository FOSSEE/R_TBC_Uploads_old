#1_16.R
#page Number 29
#question number on page is Example 2
#Section 1.4
#2x6^3-2x^2+12x-6=a(x^3-2x^2-5s-3)+b(3x^3-5x^2-4x-9)
#These yeild a set of eqns in a and b.
#In matrix form.
A<-matrix(c(1,3,-2,-5,-5,-4,-3,-9),nrow = 4,ncol = 2,byrow = TRUE)
b<-matrix(c(2,-2,12,-6),nrow = 4,ncol = 1,byrow = TRUE)
Q<-lsfit(A,b)
a=Q$coefficients[2]
b=Q$coefficients[3]
print(a)
print(b)
#Hence 2x6^3-2x^2+12x-6 is a linear combination of x^3-2x^2-5s-3 and 3x^3-5x^2-4x-9.
#Let 3x^3-2x^2+7x+8= a(x^3-2x^2-5s-3)+b(3x^3-5x^2-4x-9)
#This Yield to a set of eqns in a and b.
#A is same as before.
b2<-matrix(c(3,-2,7,8),nrow = 4,ncol = 1,byrow = TRUE)
lsfit(A,b2)
#This shows that Second has no solution.This is a closest approximation.
#So 3x^3-2x^2+7x+8 is not a linear combination of x^3-2x^2-5s-3 and 3x^3-5x^2-4x-9.