#1_2.R
#Page Number 5
#A,B,C are three point 
A <-c(1,0,2)
B <-c(-3,-2,4)
C <-c(1,8,-5)
AB=B-A #AB is the vector line starting from A and Ending At B.
AC=C-A #AC is the vector line starting from A and Ending at C
#Equation of plane containg Three points
s=1
t=1
x=A+s*AB+t*AC
print(x)

