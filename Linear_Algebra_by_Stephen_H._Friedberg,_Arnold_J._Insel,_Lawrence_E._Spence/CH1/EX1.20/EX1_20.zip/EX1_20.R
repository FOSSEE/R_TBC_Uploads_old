#EX1_20.R
#page Number 37
#Question Number on page is Example 1
#Section 1.5
S1<-c(1,3,-4,2)
S2<-c(2,2,-4,0)
S3<-c(1,-3,2,-4)
S4<-c(-1,0,1,0)
S<-c(S1,S2,S3,S4)
#Let a1,a2,a3,a4 be 
A<-matrix(c(1,2,1,-1,3,2,-2,0,-4,-4,2,1,2,0,-4,0),nrow = 4,ncol = 4,byrow = TRUE)
b<-matrix(c(0,0,0,0),nrow = 4,ncol = 1,byrow = TRUE)
#one Such Solution is 
a1<-4
a2<--3
a3<-2
a4<-0
#Then ,Let T be sum of products of S and solutions.
T<-a1%*%S1+a2%*%S2+a3%*%S3+a4%*%S4
print(T)
#This shows that T is zero.