#EX1_22.R
#page Number 38
#Question Number on page is Example 3
#Question Inference: To prove that the given set is linearly Independent.
#Let S be any set
S<-c(c(1,0,0-1),c(0,1,0,-1),c(0,0,1,-1),c(0,0,0,1))
#a1,a2,a3,a4 be Scalars such that
#a1(1,0,0,-1)+a2(0,1,0,-1)+a3(0,0,1,-1)+a4(0,0,0,1) = (0,0,0,0).
a1<-c()
a2<-c()
a3<-c()
a4<-c()
#On solving we get 
print("a1 =")
print(S*a1)
print("a2 =")
print(S*a2)
print("a3 =")
print(S*a3)
print("a4 =")
print(S*a4)

