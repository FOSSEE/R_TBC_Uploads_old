#EX1_30.R
#page Number 47
#Question Number on page is Example 7
#Section 1.6
#Question Inference : A Vector space or Matrix having 0 dimenion
#A is vector space 0.
A<-{0}
dim(A)
