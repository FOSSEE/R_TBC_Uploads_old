#EX1_31.R
#page Number 47
#Question Number on page is Example 8
#Section 1.6
#Question Inference : A Vector space or Matrix having n Dimension.
F <-matrix(c(0,0,1,1,1,2,2,3,1),nrow = 3,ncol = 3,byrow = TRUE)
n <-10
A <-matrix(c(0),nrow = nrow(F)*n,ncol = ncol(F)*n,byrow = TRUE)
dim(A)
