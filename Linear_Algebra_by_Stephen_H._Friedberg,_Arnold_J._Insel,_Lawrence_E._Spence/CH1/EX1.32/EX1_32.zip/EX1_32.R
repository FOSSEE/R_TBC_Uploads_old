#EX1_32.R
#page Number 47
#Question Number on page is Example 9
#Section 1.6
#Question Inference : A Vector space or Matrix having n and m Dimension.
F <-matrix(c(0,0,1,1,1,2,2,3,1),nrow = 3,ncol = 3,byrow = TRUE)
m <-5 #Let the Matrix in the vector space have m rows 
n <-10 #n columns.
A <-matrix(c(0),nrow = nrow(F)*m,ncol = ncol(F)*n,byrow = TRUE)
dim(A)
