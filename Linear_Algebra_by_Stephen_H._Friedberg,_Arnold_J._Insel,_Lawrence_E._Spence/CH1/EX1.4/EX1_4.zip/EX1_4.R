#EX1_4.R
#Page Number 9
#Example Number on page is Example 2
#Let two matrices be A and B.
A <- matrix(c(2,0,-1,1,-3,4),nrow = 3,ncol = 3,byrow = TRUE)
B <- matrix(c(90,0,0,0,30,0,0,0,60), nrow = 3, ncol = 3,byrow = TRUE)
AB=A+B
print(AB)
print(A)
print(B)
#This shows that sum of elements of two Diagonal matrices is sum of individual elements.
#Also Let c equal to say 2.
c <-2
AC=c*A
paste("c","*","A","=","AC",sep = "",collapse = NULL)
print(A)
print(AC)
#This shows that product of a constant and a matrix 
#is equal to product of constant and individual elements.