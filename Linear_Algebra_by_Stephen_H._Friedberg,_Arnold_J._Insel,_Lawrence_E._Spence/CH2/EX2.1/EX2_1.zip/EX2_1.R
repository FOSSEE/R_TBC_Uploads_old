#EX2_1.R
#page Number 65
#Question Number on page is Example 1
#Section 2.1
T <- function(a1=0,a2=0){
  #paste("T(a1,a2)","=","(",2*a1+a2,",",a1,")",collapse = NULL,sep = "")
  T<-c(2*a1+a2,a1)
}
#Let C be a constant say
c<-5
#assuming the value of b1 and b2
b1<-5
b2<-6
d1<-8
d2<-9
x<-c(b1,b2)
y<-c(d1,d2)
t1=T((c*x)+y)
t2=c*T(x)
t3=T(y)
t4=T(x)
#here We can understand that t1=c*t2+t3
#This is condition for given transformation to be linear.
#This is condition for given function to be linear.
print(t1)
print(t2)
print(t3)
paste("c","*",t4,"+",t3,"=",t1,sep = "",collapse = NULL)
