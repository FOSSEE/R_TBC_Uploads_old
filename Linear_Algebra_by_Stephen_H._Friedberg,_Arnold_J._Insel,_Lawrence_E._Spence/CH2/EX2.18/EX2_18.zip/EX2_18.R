#EX2_18.R
#page Number 81
#question number on page is Example 3
#Section 2.2
T <- function(a1,a2) {
  T<-matrix(c(a1+3*a2,0,2*a1-4*a2),nrow = 1,ncol = 3,byrow = TRUE)
  
}
T1<-T(1,0)
T2<-T(0,1)
#Let B and c be the ordered bases.
TBc<-matrix(c(T1,T2),nrow = 3,ncol = 2)
#Then let cdash={e3,e2,e1}
TBcdash<-matrix(c(TBc[3,],TBc[2,],TBc[1,]),nrow = 3,ncol = 2,byrow = TRUE)
print(TBcdash)                  
