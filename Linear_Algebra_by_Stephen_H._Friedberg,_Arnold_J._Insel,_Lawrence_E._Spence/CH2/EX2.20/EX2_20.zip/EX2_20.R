#EX2_20.R
#page Number 83
#question number on page is Example 5
#Section 2.2
T <- function(a1,a2) {
  T<-matrix(c(a1+3*a2,0,2*a1-4*a2),nrow = 1,ncol = 3,byrow = TRUE)
  
}
U <- function(a1,a2) {
  U<-matrix(c(a1-a2,2*a1,3*a1+2*a2),nrow = 1,ncol = 3,byrow = TRUE)
  
}
TplusU <-function(a1,a2){
  TplusU<-matrix(c(2*a1+2*a2,2*a1,5*a1-2*a2),nrow = 1,ncol = 3,byrow = TRUE)
}
T1<-T(1,0)
T2<-T(0,1)
U1<-U(1,0)
U2<-U(0,1)
TplusU1<-TplusU(1,0)
TplusU2<-TplusU(0,1)
#Let B and c be the ordered bases.
TBc<-matrix(c(T1,T2),nrow = 3,ncol = 2)
UBc<-matrix(c(U1,U2),nrow = 3,ncol = 2)
TplusUBc<-matrix(c(TplusU1,TplusU2),nrow = 3,ncol = 2)
print(TBc)
print(UBc)
print(TplusUBc)
#This shows that TplusUBc is equal to TBc+UBc