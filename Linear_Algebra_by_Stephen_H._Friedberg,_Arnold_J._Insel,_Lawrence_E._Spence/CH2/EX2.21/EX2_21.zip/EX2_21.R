#EX2_21.R
#page Number 88
#Question Number on page is Example 1
#Section 2.3
T <- function(A){ 
  T<-t(A) #This is called the Transpose of a Matrix.
}
A<-matrix(c(1,1,0,0),nrow = 2,ncol = 2,byrow = TRUE)
B<-matrix(c(0,1,1,0),nrow = 2,ncol = 2,byrow = TRUE)
AB=A*B
BA=B*A
B_transposeA_transpose=T(B)*T(A) #B_transposeA_transpose is the product of B transpose and A transpose.
print(B_transposeA_transpose)
print(T(AB))
#This shows that transpose of A*B = transpose of B*transpose of A.