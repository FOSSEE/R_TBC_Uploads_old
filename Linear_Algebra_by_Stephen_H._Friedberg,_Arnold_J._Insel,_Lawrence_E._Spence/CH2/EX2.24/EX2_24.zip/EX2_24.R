#EX2_24.R
#page Number 92
#Question Number on page is Example 4
#Section 2.3
#Let A be any Matrix.
A<-matrix(c(1,2,1,0,1,2),nrow = 2,ncol = 3,byrow = TRUE)
x<-matrix(c(1,3,-1),nrow = 3,ncol = 1,byrow = TRUE)
LA<-A %*% x
print(LA)
#Here LA is called the left-multiplication transformation.