#EX2_26,R
#page Number 100
#Question Number on page is Example 2
#Section 2.3
#Let A be any Matrix.
A<-matrix(c(5,7,2,3),nrow = 2,ncol = 2,byrow = TRUE)
solve(A) #This is FUnction to find the inverse of A.
