#EX2_3.R
#page Number 66
#Question Number on page is Example 3
#Section 2.1
T <- function(a1=0,a2=0){
  T<-c(a1,-a2)
}
#Let a1 a2 be two numbers say
a1<-5
a2<-6
#let t1 be 
t1=T(a1,a2)
#t1 is called Reflection of (a1,a2) about x-axis.
paste(t1,"is the reflection of (a1,a2) about x-axis.")
