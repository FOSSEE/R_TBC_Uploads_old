#EX2_36.R
#page Number 119
#Question Number on page is Example 1
#Section 2.6
#Let h be defined in V->R.
#x be any function of t.
x<-function(t)(t)
#g be any function of t such that g is subset of 
#vector space of real valued functions(V).
g<-function(t)(2*t)
h<-function(t)(x(t)*g(t))
print(h)
h=(1/(2*pi))*(integrate(h, lower = 0,upper = (2*pi)))

