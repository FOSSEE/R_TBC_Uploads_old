#EX2_5.R
#page Number 67
#Question Number on page is Example 5
#Section 2.1
T <- function(A){ 
  T<-t(A) #This is called the Transpose of a Matrix.
}
#Let A,B be two Matrix.
A<-matrix(c(1,2,3,4,5,6,7,8,9),nrow = 3,ncol = 3,byrow = TRUE)
B<-matrix(c(10,11,12,13,14,15,16,17,18), nrow = 3, ncol = 3,byrow = TRUE)

#let c be any constant say 
c<-5
t1<-c*T(A)
t2<-T(B)
t3=T(c*A+B)
print(t3)
print(t2)
print(t1)
paste("c","*",t1,"+","t2","=",t3)
#This shows that Transpose of matrix is linear.

