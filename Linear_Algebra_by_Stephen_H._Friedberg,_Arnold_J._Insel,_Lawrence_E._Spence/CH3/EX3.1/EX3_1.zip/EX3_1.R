#EX3_1.R
#page Number 148
#Question Number on page is Example 1
#Section 3.1
A<-matrix(c(1,2,3,4,2,1,-1,3,4,0,1,2), nrow = 3, ncol = 4,byrow = TRUE)
print(A)
#Interchanging the first row with second row
B<-matrix(c(A[2,],A[1,],A[3,]),nrow = 3,ncol = 4,byrow = TRUE)# This is row operation of type 1.
print(B) 
#Mutliplying Second row of A by 3
C<-matrix(c(A[,1],3*A[,2],A[,3],A[,4]), nrow = 3, ncol = 4)
#This is column operation of type 2.
print(C)
#Adding 3 times the 3rd row to first row,
D<-matrix(c(4*A[3,]+A[1,],A[2,],A[3,]), nrow = 3, ncol = 4,byrow = TRUE)
#This is an row operation of second type.
print(D)
