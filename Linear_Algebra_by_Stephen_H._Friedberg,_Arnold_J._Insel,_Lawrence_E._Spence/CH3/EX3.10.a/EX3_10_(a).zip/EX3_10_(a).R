#EX3_10_a.R
#page Number 170
#Question Number on page is Example 1(a)
#Section 3.3
#x1 and x2 are two variable Numbers.
#x1+x2=3
#x1-x2=1
A<-matrix(c(1,1,1,-1), nrow = 2, ncol = 2,byrow = TRUE)
b<-matrix(c(3,1),nrow = 2,ncol = 1,byrow = TRUE)
solve(A,b)
#The solution matrix x1 is equal to solve (A,b).
#                    x2 
#This system of equations has a unique solution.