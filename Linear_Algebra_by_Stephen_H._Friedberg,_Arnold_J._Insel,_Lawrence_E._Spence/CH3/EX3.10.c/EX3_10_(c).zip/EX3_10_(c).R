#EX3_10_c.R
#page Number 170
#Question Number on page is Example 1(c) 
#Section 3.3
#x1 and x2 are two variables.
#x1+x2=0
#x1+x2=1
A<-matrix(c(1,1,1,1),nrow = 2,ncol = 2,byrow = TRUE)
b<-matrix(c(0,1), nrow = 2, ncol = 1,byrow = TRUE)
solve(A,b)
#This question Should show an error because this system of equations does not have a
#real solution.