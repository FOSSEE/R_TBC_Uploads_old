#EX3_13.R
#page Number 174
#Question Number on page is Example 4
#Section 3.3
#x1,x2,x3 are 3 variables.
#2x2+4x3=2
#2x1+4x2+2x3=3
#3x1+3x2+x3=1
A<-matrix(c(0,2,4,2,4,2,3,3,1),nrow = 3,ncol = 3,byrow = TRUE)
b<-matrix(c(2,3,1),nrow = 3,ncol = 1,byrow = TRUE)
solve(A,b)
#                    x1
#The solution matrix x2 is equal to solve (A,b).
#                    x3 
#This system of equations has a unique solution.