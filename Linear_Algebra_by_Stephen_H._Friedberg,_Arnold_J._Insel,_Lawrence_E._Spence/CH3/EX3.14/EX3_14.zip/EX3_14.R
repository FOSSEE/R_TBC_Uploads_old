#EX3_14.R
#page Number 175
#Question Number on page is Example 5
#Section 3.3
#x1,x2 are 2 variables.
#x1+x2=0
#x1+x2=1
A<-matrix(c(1,1,1,1),nrow = 2,ncol = 2,byrow = TRUE)
b<-matrix(c(0,1),nrow = 2,ncol = 1,byrow = TRUE)
#C=(A|b) ie adding b as column to A.
c<-matrix(c(1,1,0,1,1,1),nrow = 2,ncol=3,byrow = TRUE)
print(c)
qr(c)
qr(A)
#the rank of c is 2 and rank of A is 1.
#This shows that the system has no solution.
