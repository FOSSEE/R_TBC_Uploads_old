#EX3_2.R
#page Number 148
#Question Number on page is Example 1
#Section 3.1
A<-matrix(c(1,2,3,4,2,1,-1,3,4,0,1,2), nrow = 3, ncol = 4,byrow = TRUE)
B<-matrix(c(A[2,],A[1,],A[3,]),nrow = 3,ncol = 4,byrow = TRUE)
E<-matrix(c(I[2,],I[1,],I[3,]),nrow = 3,ncol = 3,byrow = TRUE)
print(E%*%A)
print(B)
#This shows that E*A=B
C<-matrix(c(A[,1],3*A[,2],A[,3],A[,4]), nrow = 3, ncol = 4)
I4<-matrix(c(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),nrow = 4,ncol = 4,byrow = TRUE)
E2<-matrix(c(I4[,1],3*I4[,2],I4[,3],I4[,4]),nrow = 4,ncol = 4)
print(A%*%E2)
print(C)
#This Shows that A*E2=C

