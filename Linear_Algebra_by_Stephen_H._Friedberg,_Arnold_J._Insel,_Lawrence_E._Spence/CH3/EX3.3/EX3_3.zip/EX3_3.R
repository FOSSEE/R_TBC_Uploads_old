#EX3_3.R
#page Number 154
#Question Number on page is Example 1
#Section 3.2
A<-matrix(c(1,0,1,0,1,1,1,0,1), nrow = 3, ncol = 3,byrow = TRUE)
rankA<-qr(A) 
rankA$rank #This is functions which show the rank of a matrix.
