#EX3_3.R
#page Number 154
#Question Number on page is Example 1
#Section 3.2
A<-matrix(c(1,2,1,1,0,3,1,1,2), nrow = 3, ncol = 3,byrow = TRUE)
rankOfA=qr(A) #This is functions which show the rank of a matrix.
rankOfA$rank
