#EX3_8.R
#page Number 164
#Question Number on page is Example 6
#Section 3.2
A<-matrix(c(1,2,1,2,1,-1,1,5,4), nrow = 3, ncol = 3,byrow = TRUE)
solve(A)
#This should show an error because A does not have Inverse.
#So A is Not Invertible.