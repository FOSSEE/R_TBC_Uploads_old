#EX4_1.R
#page Number 200
#Question Number on page is Example 1
#Section 4.1
A=matrix(c(1,2,3,4),nrow = 2,ncol = 2,byrow = TRUE)
B=matrix(c(3,2,6,4),nrow = 2,ncol=2,byrow = TRUE)
a<-det(A)
b<-det(B)
C=A+B
c<-det(C)
print(a+b)
print(c)
#This shows that determinant of A+B is not equal to determinant A +determinant B
#This shows that Determinant Function is not a linear Transformation.