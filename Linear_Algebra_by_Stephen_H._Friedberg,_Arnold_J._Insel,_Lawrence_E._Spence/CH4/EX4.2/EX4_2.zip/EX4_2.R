#EX4_2.R
#page Number 210
#Question Number on page is Example 1
#Section 4.2
A<-matrix(c(1,3,-3,-3,-5,2,-4,4,-6),nrow = 3,ncol = 3,byrow = TRUE)
print(det(A))
