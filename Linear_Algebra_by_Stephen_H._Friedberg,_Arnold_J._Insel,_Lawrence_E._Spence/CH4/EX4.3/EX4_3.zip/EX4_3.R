#EX4_3.R
#page Number 211
#Question Number on page is Example 2
#Section 4.2
A<-matrix(c(0,1,3,-2,-3,-5,4,-4,4),nrow = 3,ncol = 3,byrow = TRUE)
print(det(A))
