#EX4_4.R
#page Number 211
#Question Number on page is Example 3
#Section 4.2
A<-matrix(c(2,0,0,1,0,1,3,-3,-2,-3,-5,2,4,-4,4,-6),nrow = 4,ncol = 4,byrow = TRUE)
print(det(A))
