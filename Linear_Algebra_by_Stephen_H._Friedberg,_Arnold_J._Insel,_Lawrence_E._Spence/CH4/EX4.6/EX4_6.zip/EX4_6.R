#EX4_6.R
#page Number 218
#Question Number on page is Example 5
#Section 4.2
B<-matrix(c(0,1,3,-2,-3,-5,4,-4,4),nrow = 3,ncol = 3,byrow = TRUE)
print(B)
#Let C be matric obtained by interchanging the row 1 and 2.
C<-matrix(c(B[2,],B[1,],B[3,]),nrow = 3,ncol = 3,byrow = TRUE)
det_c<-det(C)
print(det_c)
#C was produced by performing a row operation on B
#so det(B)=-det(C)
det_b=-det_c
print(det_b)
