#EX4_7.R
#page Number 219
#Question Number on page is Example 6
#Section 4.2
C<-matrix(c(2,0,0,1,0,1,3,-3,-2,-3,-5,2,4,-4,4,-6),nrow = 4,ncol = 4,byrow = TRUE)
det_c<-det(C)
print(det_c)
#The Determinant of Given matrix is 32.