#EX4_8.R
#page Number 225
#Question Number on page is Example 1
#Section 4.3
#x1+2x2+3x3=2
#x1+x3=3
#x1+x2-x3=1
A<-matrix(c(1,2,3,1,0,1,1,1,-1),nrow = 3,ncol = 3,byrow = TRUE)
print(A)
b<-matrix(c(2,3,1),nrow=3,ncol = 1,byrow = TRUE)
#x1 is obtained by det(replacing first Column with b)/det(A)
#Similarly x2 and x3 are obtained.
a=matrix(c(2,2,3,3,0,1,1,1,-1),nrow = 3,ncol = 3,byrow = TRUE)
b=matrix(c(1,2,3,1,3,1,1,1,-1),nrow = 3,ncol = 3,byrow = TRUE)
c=matrix(c(1,2,2,1,0,3,1,1,1),nrow = 3,ncol = 3,byrow = TRUE)
print(c)
x1=det(a)/det(A)
x2=det(b)/det(A)
x3=det(c)/det(A)
print(x1)
print(x2)
print(x3)
#Using this method we get the vlues of x1,x2,x3.