#EX4_9.R
#page Number 226
#Question Number on page is Example 2
#Section 4.3
a1<-c(1,-2,1)
a2<-c(1,0,-1)
a3<-c(1,1,1)
A<-matrix(c(a1,a2,a3),nrow = 3,ncol = 3,byrow = TRUE)
det(A)
#so lengths of sides of parallelopipes are,
l1<-sqrt(6)
l2<-sqrt(2)
l3<-sqrt(3)
VolumeOfParallelopiped<-l1*l2*l3
print(VolumeOfParallelopiped) #This Gives the volume of parallelopiped.
