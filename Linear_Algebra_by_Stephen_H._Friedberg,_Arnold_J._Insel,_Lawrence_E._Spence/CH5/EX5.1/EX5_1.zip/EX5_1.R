#EX5_1.R
#page Number 247
#Question Number on page is Example 1
#Section 5.1
A<-matrix(c(1,3,4,2),nrow = 2,ncol = 2,byrow = TRUE)
e<-eigen(A)
e$values
#Let v1 and v2 are two eigen Vectors.
v1<-matrix(c(3,4),nrow = 2,ncol = 1,byrow = TRUE) 
v2<-matrix(c(1,-1),nrow = 2,ncol = 1,byrow = TRUE)
paste(e$values[1],"is the Eigen Value Corresponding to v1.")
paste(e$values[2],"is the Eigen Value Corresponding to v2.")