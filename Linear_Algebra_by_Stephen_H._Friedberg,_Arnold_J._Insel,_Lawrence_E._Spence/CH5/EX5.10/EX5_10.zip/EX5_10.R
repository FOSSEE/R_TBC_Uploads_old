#EX5_10.R
#page Number 264
#Question Number on page is Example 3
#Section 5.2
#T be a linear Operation as T(f(x))=f'(x).
TB<-matrix(c(0,1,0,0,0,2,0,0,0),nrow = 3,ncol = 3,byrow = TRUE)
e<-eigen(TB)
e$values
paste(e$values,"is a Eigen value of Given Matrix.")
#On Observing the values of Eigen Values we get that,
#lampda=0 with a multiplicity of 3.
#Also this implies that T is not diagonalizable.
