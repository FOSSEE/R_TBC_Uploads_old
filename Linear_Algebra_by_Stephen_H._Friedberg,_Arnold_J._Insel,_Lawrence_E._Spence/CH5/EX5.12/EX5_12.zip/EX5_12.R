#EX5_12.R
#page Number 269
#Question Number on page is Example 5
#Section 5.2
A<-matrix(c(3,1,0,0,3,0,0,0,4),nrow = 3,ncol = 3,byrow = TRUE)
I<-matrix(c(1,0,0,0,1,0,0,0,1),nrow = 3,ncol = 3,byrow = TRUE)
e<-eigen(A)
e$values
lampda1=e$values[1] #The Multiplicity of lampda1 is 1
lampda2=e$values[2] 
A2<-A-(lampda2*I)
print(A2)
qr(A2)
#From qr(A2) we observe that rank of A2 is 2
#lampda2-rank(A2) is 1 which is not the multiplicity of lampda2.
#This implies that A is not diagonalizable.