#EX5_4.R
#page Number 248
#Question Number on page is Example 4
#Section 5.1
A<-matrix(c(1,1,4,1),nrow = 2,ncol = 2,byrow = TRUE)
e<-eigen(A)
e$values
paste(e$values,"is a Eigen value of Given Matrix.")

