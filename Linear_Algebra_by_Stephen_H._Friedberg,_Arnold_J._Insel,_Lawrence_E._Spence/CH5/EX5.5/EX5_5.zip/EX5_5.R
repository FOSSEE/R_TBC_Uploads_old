#EX5_5.R
#page Number 249
#Question Number on page is Example 5
#Section 5.1
A<-matrix(c(1,1,0,0,2,2,0,0,3),nrow = 3,ncol = 3,byrow = TRUE)
e<-eigen(A)
e$values
paste(e$values,"is a Eigen value of Given Matrix.")

