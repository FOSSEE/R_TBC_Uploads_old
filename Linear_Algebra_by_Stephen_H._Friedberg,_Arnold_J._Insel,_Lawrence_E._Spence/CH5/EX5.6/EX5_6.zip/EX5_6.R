#EX5_6.R
#page Number 250
#Question Number on page is Example 6
#Section 5.1
A<-matrix(c(1,1,4,1),nrow = 2,ncol = 2,byrow = TRUE)
I<-matrix(c(1,0,0,1),nrow = 2,ncol = 2,byrow = TRUE)
e<-eigen(A)
e$values
lampda1<-e$values[1]
lampda2<-e$values[2]
B1<-A-(lampda1*I)
B2<-A-(lampda2*I)
print(B1)
print(B2)
e$vectors
EigenVectors<-(e$vectors/e$vectors[1])
print(EigenVectors)
paste(EigenVectors[,1],"is a Eigen Vectors of A")
paste(EigenVectors[,2],"is a Eigen Vectors of A")
