#EX5_8.R
#page Number 262
#Question Number on page is Example 1
#Section 5.2
A<-matrix(c(1,1,1,1),nrow = 2,ncol = 2,byrow = TRUE)
e<-eigen(A)
e$values
paste(e$values,"is a Eigen value of Given Matrix.")
#Since the Eigen Values are Distinct, A is Diagonalizable.
