#EX5_9.R
#page Number 263
#Question Number on page is Example 2
#Section 5.2
A<-matrix(c(3,1,0,0,3,4,0,0,4),nrow = 3,ncol = 3,byrow = TRUE)
e<-eigen(A)
e$values
paste(e$values,"is a Eigen value of Given Matrix.")
#On Observing the Output of Eigen Values,we get
#The Multiplicity of lampda=3 is 2
#and the Multiplicity of lampda=4 is 1.
