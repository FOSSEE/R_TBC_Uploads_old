#EX6_23.R
#page Number 365
#Question Number on page is Example 3
#Section 6.3
A=matrix(c(1,2,1,1,-1,2,1,5,0),nrow = 3,ncol = 3,byrow = TRUE)
b=matrix(c(4,-11,19),nrow = 3,ncol = 1,byrow = TRUE)
#Let X=matrix(c(x,y,z),ncol=3,ncol(1),byrow = TRUE) be the matrix.
print(b)
Astar=Conj(t.default(A))
A3=A %*% Astar
#Then we consider A3*X=b.
#For This One solution is 
u=matrix(c(1,-2,0),nrow = 3,ncol = 1,byrow = TRUE)
#So the Minimal Solution to the given system is,
s=A %*% u
print(s)

