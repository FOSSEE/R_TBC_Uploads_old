#EX6_24.R
#page Number 371
#Question Number on page is Example 1
#Section 6.4
#Let It rotate by angle q say 90 Degree.
q<-pi/2
A<-matrix(c(cos(q),-sin(q),sin(q),cos(q)),nrow = 2,ncol = 2,byrow = TRUE)
A2=Conj(t.default(A))
A3=A %*% A2
A4=A2 %*% A
I2=matrix(c(1,0,0,1),nrow = 2,ncol = 2,byrow = TRUE)
print(A3)
print(A4)
print(I2)
#this shows that A*AT=AT*A=I
