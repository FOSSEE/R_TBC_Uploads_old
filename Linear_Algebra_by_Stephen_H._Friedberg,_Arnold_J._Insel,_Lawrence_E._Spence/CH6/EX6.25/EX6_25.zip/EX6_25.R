#EX6_25.R
#page Number 371
#Question Number on page is Example 2
#Section 6.4
#Let A be a skew Symmetric Matrix,
A<-matrix(c(0,-6,4,-6,0,7,4,7,0),nrow = 3,ncol = 3,byrow = TRUE)
AT<-t.default(A)
Asquared=A %*% A
A3=A %*% AT
A4=AT %*% A
print(A3)
print(Asquared)
print(A4)
#This shows that A*AT=AT*A so A is normal.
