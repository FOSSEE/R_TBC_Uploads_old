#EX6_27.R
#page Number 374
#Question Number on page is Example 4
#Section 6.4
A<-matrix(c(complex(imaginary = 1),complex(imaginary = 1),complex(imaginary = 1),1),nrow = 2,ncol = 2,byrow = TRUE)
Astar=Conj(t.default(A))
print(Astar)
A3=A%*%Astar
A4=Astar%*%A
print(A3)
print(A4)
#This shows that A*Astar!=Astar*A That is
#Complex symmetric Matrices may not be Normal.