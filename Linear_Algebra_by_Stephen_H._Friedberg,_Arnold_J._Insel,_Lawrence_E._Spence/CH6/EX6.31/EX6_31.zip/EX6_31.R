#EX6_31.R
#page Number 383
#Question Number on page is Example 4
#Section 6.5
#Let It rotate by angle q say 90 Degree.
q<-pi/2
A<-matrix(c(cos(q),-sin(q),sin(q),cos(q)),nrow = 2,ncol = 2,byrow = TRUE)
Astar=Conj(t.default(A))
A3=A %*% Astar
A4=Astar %*% A
I2=matrix(c(1,0,0,1),nrow = 2,ncol = 2,byrow = TRUE)
print(A3)
print(A4)
print(I2)
#this shows that A*Astar=Astar*A=I Condtion 1.
Atranspose=t.default(A)
A.AT=A %*% Atranspose
AT.A=Atranspose %*% A
print(A.AT)
print(AT.A)
#This shows that A.Atranspose=Atranspose.A=I Condition 2.
#Because This matrix satisfies condition 1 and 2 It is Orthogonal.