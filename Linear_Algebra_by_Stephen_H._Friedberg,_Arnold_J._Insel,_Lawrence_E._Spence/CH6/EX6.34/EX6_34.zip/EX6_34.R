#EX6_34.R
#page Number 388
#Question Number on page is Example 7
#Section 6.5
sq5=sqrt(5)
A<-matrix(c(1/sq5,2/sq5,2/sq5,-1/sq5),nrow = 2,ncol = 2,byrow = TRUE)  
print(A)
Astar=Conj(t.default(A))
A3=A%*%Astar
A4=Astar%*%A
print(A3)
print(A4)
#This shows that A*Astar=Astar*A 
#So The given Matrix is orthogonal.
#LA is an Orthogonal Operator.
detA=det(A)
print(detA)
#Thus LA is Reflection about line L through origin.
#This implies that eigen value of L is 1
#such a vector is 
v<-c(2,sq5-1)
#so slope of L ,when x is any value say 5.
x<-5
y=(sq5-1/2)*x
print(y)
