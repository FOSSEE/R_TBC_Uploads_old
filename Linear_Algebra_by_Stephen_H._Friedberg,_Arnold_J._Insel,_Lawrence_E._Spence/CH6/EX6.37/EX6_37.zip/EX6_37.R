#EX6_37.R
#page Number 411
#Question Number on page is Example 3
#Section 6.7
A<-matrix(c(1,1,-1,1,1,-1),nrow = 2,ncol = 3,byrow = TRUE)
#we Observe that 
v1=(1/sqrt(3))*matrix(c(1,1,-1),nrow = 3,ncol = 1,byrow = TRUE)
v2=(1/sqrt(2))*matrix(c(1,-1,0),nrow = 3,ncol = 1,byrow = TRUE)
v3=(1/sqrt(6))*matrix(c(1,1,2),nrow = 3,ncol = 1,byrow = TRUE)
#We observe that eigen value of these vectors are lampda1=6,lampda2=lampda3=0
sig1=sqrt(6)
Sigma=matrix(c(sig1,0,0,0,0,0),nrow = 2,ncol = 3,byrow = TRUE)
V=matrix(c(v1,v2,v3),nrow = 3,ncol = 3)
#u1 and u2 be unit vectors.
u1=(1/sqrt(2))*matrix(c(1,1),nrow = 2,ncol = 1,byrow = TRUE)
#U2 is picked so that it is orthogonal to u1.
u2=(1/sqrt(2))*matrix(c(1,-1),nrow = 2,ncol = 1,byrow = TRUE)
#Next U
U=matrix(c(u1,u2),nrow = 2,ncol = 2)
print(U)
#This is called singular value decomposition.

