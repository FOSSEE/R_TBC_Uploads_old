#EX6_38.R
#page Number 412
#Question Number on page is Example 4
#Section 6.7
A<-matrix(c(11,-5,-2,10),nrow = 2,ncol = 2,byrow = TRUE)
#we Observe that 
v1=(1/sqrt(2))*matrix(c(1,-1),nrow = 2,ncol = 1,byrow = TRUE)
v2=(1/sqrt(2))*matrix(c(1,1),nrow = 2,ncol = 1,byrow = TRUE)
#We observe that eigen value of these vectors are lampda1=200,lampda2=50
sig1=sqrt(200)
sig2=sqrt(50)
Sigma=matrix(c(sig1,0,0,sig2),nrow = 2,ncol = 2,byrow = TRUE)
V=matrix(c(v1,v2),nrow = 2,ncol = 2)
#u1 and u2 be unit vectors.
u1=(1/5)*(matrix(c(4,-3),nrow = 2,ncol = 1,byrow = TRUE))
#U2 is picked so that it is orthogonal to u1.
u2=(1/5)*(matrix(c(3,4),nrow = 2,ncol = 1,byrow = TRUE))
#Next U
U=matrix(c(u1,u2),nrow = 2,ncol = 2)
Vstar=t.default(V)
W=U %*% Vstar
P=V %*% Sigma %*% Vstar
print(P)
print(W)
#This is called polar decomposition.

