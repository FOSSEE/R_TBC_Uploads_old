#EX6_4.R
#page Number 331
#Question Number on page is Example 4
#Section 6.1
a1=complex(real = 0,imaginary = 1)
a2=complex(real = 1,imaginary = 2)
a3=complex(real = 3,imaginary = 4)
A<-matrix(c(a1,a2,2,a3),nrow = 2,ncol = 2,byrow = TRUE)
Conj(t.default(A)) #This is the Conjugate transpose of A.
