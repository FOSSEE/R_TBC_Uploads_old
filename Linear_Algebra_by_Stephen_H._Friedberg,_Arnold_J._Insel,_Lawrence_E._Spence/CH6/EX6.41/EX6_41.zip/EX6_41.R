#EX6_41.R
#page Number 417
#Question Number on page is Example 7 
#Section 6.7
A<-matrix(c(1,1,-1,1,1,-1),nrow = 2,ncol = 3,byrow = TRUE)
b<-matrix(c(1,1),nrow = 2,ncol = 1,byrow = TRUE)
#we Observe that 
v1=(1/sqrt(3))*matrix(c(1,1,-1),nrow = 3,ncol = 1,byrow = TRUE)
v2=(1/sqrt(2))*matrix(c(1,-1,0),nrow = 3,ncol = 1,byrow = TRUE)
v3=(1/sqrt(6))*matrix(c(1,1,2),nrow = 3,ncol = 1,byrow = TRUE)
#We observe that eigen value of these vectors are lampda1=6,lampda2=lampda3=0
sig1=sqrt(6)
Sigma=matrix(c(sig1,0,0,0,0,0),nrow = 2,ncol = 3,byrow = TRUE)
#Sigma Star is used to calculate Psudeinverse.
SigmaStar=matrix(c(1/sig1,0,0,0,0,0),nrow = 3,ncol = 2,byrow = TRUE)
V=matrix(c(v1,v2,v3),nrow = 3,ncol = 3)
#u1 and u2 be unit vectors.
u1=(1/sqrt(2))*matrix(c(1,1),nrow = 2,ncol = 1,byrow = TRUE)
#U2 is picked so that it is orthogonal to u1.
u2=(1/sqrt(2))*matrix(c(1,-1),nrow = 2,ncol = 1,byrow = TRUE)
#Next U
U=matrix(c(u1,u2),nrow = 2,ncol = 2)
print(U)
Apsudoinverse=V %*% SigmaStar %*% U
print(Apsudoinverse)
#This Gives the PsudoInverse of A.
z=Apsudoinverse %*% b
print(z)
#Z is the solution of minimal norm.
#Considering Second Set of Eqns.
#This system is inconsistent.
#A is same.
b2<-matrix(c(1,2),nrow = 2,ncol = 1,byrow = TRUE)
z=Apsudoinverse %*% b2
print(z)
#Here z is not a solution to the given system of eqns. 
#But z is the best approximation to solution having minimum norm.