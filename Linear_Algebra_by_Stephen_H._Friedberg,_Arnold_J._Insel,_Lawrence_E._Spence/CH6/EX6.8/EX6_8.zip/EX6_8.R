#EX6_8.R
#page Number 335
#Question Number on page is Example 8
#Section 6.1
detach("package:pracma", unload=TRUE)
library("pracma", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.4")
a1<-c(1,1,0)
a2<-c(1,-1,1)
a3<-c(-1,1,2)
S<-c(a1,a2,a3)
#S is not OrthoNormal set. 
a4<-(1/Norm(a1))*(a1) 
a5<-(1/Norm(a2))*(a2)
a6<-(1/Norm(a3))*(a3)
S2<-c(a4,a5,a6)
print(S2)
#S2 is the Required Orthonormal Set.