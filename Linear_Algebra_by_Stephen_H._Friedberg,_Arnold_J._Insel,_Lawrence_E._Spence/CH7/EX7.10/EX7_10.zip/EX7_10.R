#EX7_10.R
#page Number 518
#Question Number on page is Example 2
#Section 7.3
library("polynom", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.4")
A<-matrix(c(2,5,6,1),nrow = 2,ncol = 2,byrow = TRUE)

eigVals <- eigen(A)$values
multEig <- table(eigVals)
k <- length(multEig)
ratPoly <- minPoly <- 1
for(i in 1:k){
  poly.i <- polynomial(c(-as.numeric(names(multEig)[i]), 1))
  minPoly <- (minPoly*poly.i)
  if(multEig[i]>1)
    ratPoly <- (ratPoly*poly.i^(multEig[i]-1))
}
#Minimum Polinomial is 
minPoly

