#EX7_8.R
#page Number 508
#Question Number on page is Example 5
#Section 7.2
A<-matrix(c(-3,3,-2,-7,6,-3,1,-1,2),nrow = 3,ncol = 3,byrow = TRUE)
B<-matrix(c(0,1-1,-4,4,-2,-2,1,1),nrow = 3,ncol = 3,byrow = TRUE)
C<-matrix(c(0,-1,-1,-3,-1,-2,7,5,6),nrow = 3,ncol = 3,byrow = TRUE)
D<-matrix(c(0,1,2,0,1,1,0,0,2),nrow = 3,ncol = 3,byrow = TRUE)
#we Observe that A,B,C have Characteristic polynomials.
#So A,B,C are similar.
#also We Observe that the Jordan Cannonical Forms of A,B,C are,
JA=matrix(c(1,0,0,0,2,1,0,0,2),nrow = 3,ncol = 3,byrow = TRUE)
JB=matrix(c(1,0,0,0,2,0,0,0,2),nrow = 3,ncol = 3,byrow = TRUE)
JC=matrix(c(1,0,0,0,2,1,0,0,2),nrow = 3,ncol = 3,byrow = TRUE)
#Since JA and JC are equal And C are Similar and B is similar to Niether A nor C.  