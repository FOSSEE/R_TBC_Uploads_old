#EX7_9.R
#page Number 518
#Question Number on page is Example 1
#Section 7.3
library("polynom", lib.loc="~/R/x86_64-pc-linux-gnu-library/3.4")
A<-matrix(c(3,-1,0,0,2,0,1,-1,2),nrow = 3,ncol = 3,byrow = TRUE)
eigVals <- eigen(A)$values
multEig <- table(eigVals)
k <- length(multEig)
ratPoly <- minPoly <- 1
for(i in 1:k){
  poly.i <- polynomial(c(-as.numeric(names(multEig)[i]), 1))
  minPoly <- (minPoly*poly.i)
  if(multEig[i]>1)
    ratPoly <- (ratPoly*poly.i^(multEig[i]-1))
}
#Minimum Polinomial is 
minPoly

