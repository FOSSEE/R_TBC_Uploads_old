#page - 27
#section - 1.4 MATRIX ADDITION AND SCALAR MULTIPLICATION
#example 6


#first matrix M
M <- matrix(c(3,0,7,-2,4,0,5,6,0), 3, 3)
M
#second matrix S
S <- matrix(c(-3,0,-7,2,-4,0,-5,-6,0), 3, 3)
S
#adding M and S to C
C <- M + S

#printing C
C