#page - 30
#section - 1.4 MATRIX ADDITION AND SCALAR MULTIPLICATION
#example 7


#first matrix A
A <- matrix(c(1,4,2,0,-3,5), 2, 3)
A
#second matrix B
B <- matrix(c(4,8,-7,7,3,0), 2,3)
B
#performing the action 2A-3B and equating it to C
C <- (A*2) - (B*3)


#printing C
C