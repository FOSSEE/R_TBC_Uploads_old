# Statistics for Management and Economics by Gerald Keller
# Chapter 14: ANALYSIS OF VARIANCE
# Example 14.1 on Pg 526
# Proportion of Total Assets Invested in Stocks


data1 <- read.csv(file.choose()) #choose Xm14-01.csv

summary(aov(data1$Investment ~ data1$Group))

#Answer:
#F-statistic: 2.79
#Df Sum Sq Mean Sq F value Pr(>F)  
#data1$Group   3   3746  1248.7   2.792 0.0403 *
#  Residuals   362 161892   447.2                 

#End