# Statistics for Management and Economics by Gerald Keller
# Chapter 16: SIMPLE LINEAR REGRESSION AND CORRELATION
# Example 16.2 on Pg 641
# Odometer Reading and Prices of Used Toyota Camrys, Part 1 

data1 <- read.csv(file.choose()) #choose Xm16-02.csv


Odometer <- data1$Odometer
#number of miles in 1000 mi on odometer - Explanatory variable

Price <- data1$Price #Price in 1000$ - Respone variable

#determine the straight line relationship between Car Selling Price and Car Odometer reading in miles
#using least squares

regression_line <- lm(Price ~ Odometer) #gives regression line
summary(regression_line) #gives the Residuals, Std Error etc

cat("The least squares or regression line is Y =", 
    regression_line$coefficients[1], regression_line$coefficients[2], "X", 
    "where Y is Car Selling Price and X is Car Odometer reading in miles")

# The least squares line is Y = 17.25 - 0.0669X

#End
