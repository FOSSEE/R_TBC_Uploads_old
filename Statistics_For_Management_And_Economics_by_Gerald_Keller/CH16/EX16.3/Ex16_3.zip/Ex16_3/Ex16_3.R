# Statistics for Management and Economics by Gerald Keller
# Chapter 16: SIMPLE LINEAR REGRESSION AND CORRELATION
# Example 16.3 on Pg 651
# Odometer Reading and Prices of Used Toyota Camrys-Part 2 


data1 <- read.csv(file.choose()) #choose Xm16-02.csv

Odometer <- data1$Odometer #number of miles in 1000 mi on odometer - Explanatory variable
Price <- data1$Price #Price in 1000$ - Respone variable

#determine the straight line relationship between Car Selling Price and Car Odometer reading in miles
#using least squares

regression_line <- lm(Price ~ Odometer) #gives regression line
s <- summary(regression_line) #gives the Residuals, Std Error etc

cat("The standard error is", s$sigma)

# The standard error is 0.3265

#End


