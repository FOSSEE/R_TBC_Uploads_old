# Statistics for Management and Economics by Gerald Keller
# Chapter 16: SIMPLE LINEAR REGRESSION AND CORRELATION
# Example 16.5 on Pg 658
# Measuring the Strength of the Linear Relationship between Odometer Reading and Price of Used Toyota Camrys 

data1 <- read.csv(file.choose()) #choose Xm16-02.csv

Odometer <- data1$Odometer
#number of miles in 1000 mi on odometer - Explanatory variable

Price <- data1$Price #Price in 1000$ - Respone variable

#Find the coefficient of determination and Interpret.

regression_line <- lm(Price ~ Odometer) #gives regression line
s<-summary(regression_line) #gives the Residuals, Std Error etc

cat("The coefficient of determination is:", s$r.squared)

#The coefficient of determination is: 0.6482955. Higher the R-squared value, better the model.
#This mean 64.83% of the variation in the auction selling prices is explained by 
#the variation in the odometer readings. The remaining 35.17% is unexplained. 

#End


