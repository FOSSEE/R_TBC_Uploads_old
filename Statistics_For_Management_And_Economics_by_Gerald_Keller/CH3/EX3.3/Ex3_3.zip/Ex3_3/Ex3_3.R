# Statistics for Management and Economics by Gerald Keller
# Chapter 3: Graphical Descriptive Techniques II
# Example 3.3 on Pg 54
# Business Statistics Marks 

data1 <- read.csv(file.choose()) #choose Xm03-03.csv

names(data1) #displays names of the variables
range(data1$Marks) #displays range of the values of the variable 'Marks'

#Histogram of Business-Statistics Marks
hist(data1$Marks, breaks=5, labels = TRUE, xlab = "Marks", main = 'Business-Statistics Marks', ylim=c(0,30),
     col='grey')

#use this Histogram for interpretation of the past year Business-Statistics marks.
#The Histogram looks symmetric and unimodal.

#End