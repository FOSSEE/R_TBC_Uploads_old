# Statistics for Management and Economics by Gerald Keller
# Chapter 3: Graphical Descriptive Techniques II
# Example 3.4 on Pg 55
# Mathematical Statistics Marks 

data1 <- read.csv(file.choose()) #choose Xm03-04.csv

names(data1) #displays names of the variables
range(data1$Marks) #displays range of the values of the variable 'Marks'

#Histogram of Mathematical-Statistics Marks
hist(data1$Marks, breaks=6,labels = TRUE, xlab = "Marks", 
     main = 'Mathematical-Statistics Marks', xlim=c(40,100), ylim=c(0,30), freq=TRUE, col='grey')

#use this Histogram for interpretation of the past year Mathematical-Statistics marks.
#The Histogram looks bimodal, suggesting two groups of students. One group is comparatively 
#weaker in Mathematics than the other.

#End