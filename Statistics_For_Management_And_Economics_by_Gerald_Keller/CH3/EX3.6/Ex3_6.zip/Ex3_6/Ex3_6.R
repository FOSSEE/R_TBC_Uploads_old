# Statistics for Management and Economics by Gerald Keller
# Chapter 3: Graphical Descriptive Techniques II
# Example 3.6 on Pg 69
# Price of Gasoline in 1982-1984 Constant Dollars

data1 <- read.csv(file.choose()) #choose Xm03-06.csv

#renaming and making a new copy of the required variable
Adj.price <- data1$Adjusted.price

#Line chart #to be used for interpretation
plot(Adj.price, xlab = 'Month', ylab = 'Adjusted price of Gasoline',
     main='Line chart of adjusted price of gasoline per gallon', type='l', col='red', ylim=c(0, 200))

#the adjusted average price of a gallon of gasoline hit its peak in June 2008. 
#Thereafter it dropped rapidly and got equal towards end of 2009 to the adjusted price in 1976. 

#End