# Statistics for Management and Economics by Gerald Keller
# Chapter 3: Graphical Descriptive Techniques II
# Example 3.7 on Pg 74
# Analyzing the Relationship between Price and Size of Houses 

data1 <- read.csv(file.choose()) #choose Xm03-07.csv

#make a scatter diagram

#renaming and making a new copy of the required variables
price <- data1$Price
size <- data1$Size

#Scatter diagram 
plot(size, price, xlab = 'Size', ylab = 'Price', main='Scatterplot of Size vs Price', type='p')
points(size, price, col="red", pch=16)

#End
