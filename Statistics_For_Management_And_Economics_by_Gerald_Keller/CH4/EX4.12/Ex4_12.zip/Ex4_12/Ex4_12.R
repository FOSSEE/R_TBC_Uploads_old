# Statistics for Management and Economics by Gerald Keller
# Chapter 4: Numerical Descriptive Techniques
# Example 4.12 on Pg 119
# Quartiles of Long-Distance Telephone Bills 

data1 <- read.csv(file.choose()) #choose Xm03-01.csv

quantile(data1$Bills, c(.25, .50, .75)) 

#Answer:
#   25%    50%     75% 
# 9.3850 26.9050 84.8275 

###Answers are slightly different from the book. Answer in the book:Q1 (9.28) | Q2 (26.91) | Q3 (84.94)

#End
