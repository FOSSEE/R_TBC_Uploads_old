# Statistics for Management and Economics by Gerald Keller
# Chapter 4: Numerical Descriptive Techniques
# Example 4.13 on Pg 120
# Interquartile Range of Long-Distance Telephone Bills 

data1 <- read.csv(file.choose()) #choose Xm03-01.csv

#IQR() function gives the interquartile range.
IQR(data1$Bills) 


#Answer: 75.4425

###Answers are slightly different from the book. Answer in the book: IQR is 75.78

#End