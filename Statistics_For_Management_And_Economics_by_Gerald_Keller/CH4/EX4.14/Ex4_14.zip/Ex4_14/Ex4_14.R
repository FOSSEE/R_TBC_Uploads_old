# Statistics for Management and Economics by Gerald Keller
# Chapter 4: Numerical Descriptive Techniques
# Example 4.14 on Pg 121
# Box Plot of Long-Distance Telephone Bills 

data1 <- read.csv(file.choose()) #choose Xm03-01.csv

#boxplot() function gives the boxplot
boxplot(data1$Bills, horizontal = TRUE, main = 'Boxplot of Bills', xlab = 'Bills', col="red")
text(x=fivenum(data1$Bills), labels = fivenum(data1$Bills), y=1.25) #shows quartile values

###Answers are slightly different from the book. 

#End