# Statistics for Management and Economics by Gerald Keller
# Chapter 4: Numerical Descriptive Techniques
# Example 4.2 on Pg 99
# Mean Long-Distance Telephone Bill 

data1 <- read.csv(file.choose()) #choose Xm03-01.csv

names(data1)

Bill <- data1$Bills

mean(Bill)

# mean long-distance telephone bill is 43.59

#End