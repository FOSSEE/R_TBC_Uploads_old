# Statistics for Management and Economics by Gerald Keller
# Chapter 4: Numerical Descriptive Techniques
# Example 4.4 on Pg 101
# Median Long-Distance Telephone Bill 

data1 <- read.csv(file.choose()) #choose Xm03-01.csv

names(data1)

Bill <- data1$Bills

median(Bill)

# Median long-distance telephone bill is 26.905
# Half the observations are below 26.905, and half the observations are above 26.905.

#End
