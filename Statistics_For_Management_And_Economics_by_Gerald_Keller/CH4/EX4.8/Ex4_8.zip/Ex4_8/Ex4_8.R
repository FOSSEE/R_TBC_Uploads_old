# Statistics for Management and Economics by Gerald Keller
# Chapter 4: Numerical Descriptive Techniques
# Example 4.8 on Pg 112
# Comparing the Consistency of Two Types of Golf Clubs 

data1 <- read.csv(file.choose()) #choose Xm04-08.csv

current <- data1$Current

new <- data1$Innovation

#basic descriptive statistics and frequencies using the function summary() 
summary(current)

#Library psych gives all relevant descriptive statistics together
install.packages("psych")
library(psych)
DS_current <- describe(current)
DS_current$sd #standard deviation of the data 'current' = 5.79

DS_new <- describe(new)
DS_new$sd #standard deviation of the data 'innovation' = 3.09

#End